/***********************************************************************************************************************
 * HEADER FILES
 **********************************************************************************************************************/
#include "bc_ccu8.h"

/***********************************************************************************************************************
 * MACROS
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * LOCAL DATA
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * LOCAL ROUTINES
 **********************************************************************************************************************/

/* Initialization of the GPIO */
void BC_CCU8_lPinInit(BC_CCU8_t* const HandlePtr)
{
	XMC_ASSERT("BC_CCU8_lPinInit:NULL Handle Pointer", (HandlePtr != (BC_CCU8_t *)NULL));

	XMC_GPIO_Init(HandlePtr->pwmoutpin_ptr[0]->port,HandlePtr->pwmoutpin_ptr[0]->pin, HandlePtr->pwmoutconfig_ptr[0]);
	XMC_GPIO_Init(HandlePtr->pwmoutpin_ptr[1]->port,HandlePtr->pwmoutpin_ptr[1]->pin, HandlePtr->pwmoutconfig_ptr[1]);
	XMC_GPIO_Init(HandlePtr->pwmoutpin_ptr[2]->port,HandlePtr->pwmoutpin_ptr[2]->pin, HandlePtr->pwmoutconfig_ptr[2]);
	XMC_GPIO_Init(HandlePtr->pwmoutpin_ptr[3]->port,HandlePtr->pwmoutpin_ptr[3]->pin, HandlePtr->pwmoutconfig_ptr[3]);
	XMC_GPIO_Init(HandlePtr->pwmoutpin_ptr[4]->port,HandlePtr->pwmoutpin_ptr[4]->pin, HandlePtr->pwmoutconfig_ptr[4]);
	XMC_GPIO_Init(HandlePtr->pwmoutpin_ptr[5]->port,HandlePtr->pwmoutpin_ptr[5]->pin, HandlePtr->pwmoutconfig_ptr[5]);
}

/* App API to retrieve the App version info */
DAVE_APP_VERSION_t BC_CCU8_GetAppVersion(void)
{
	DAVE_APP_VERSION_t version;

	version.major = BC_CCU8_MAJOR_VERSION;
	version.minor = BC_CCU8_MINOR_VERSION;
	version.patch = BC_CCU8_PATCH_VERSION;

	return version;
}

/**
 * This function initializes all the three CCU8 phases as per the user configurations
 */
BC_CCU8_STATUS_t BC_CCU8_Init(BC_CCU8_t* HandlePtr)
{
	uint8_t index;
	uint32_t init_status = (uint32_t)BC_CCU8_STATUS_SUCCESS;

	XMC_ASSERT("BC_CCU8_Init:NULL Handle Pointer",
				(HandlePtr != (BC_CCU8_t *)NULL));

	if (BC_CCU8_UNINITIALIZED == HandlePtr->state)
	{
		/* CCU8 global init to start the prescalar and de-assert the module */
		init_status  = (uint32_t)GLOBAL_CCU8_Init(HandlePtr->globalccu8_ptr);
		init_status |= (uint32_t)ZEROCROSSING_Init(HandlePtr->zerocrossing_ptr);
		BC_CCU8_lPinInit(HandlePtr);

		if (init_status == (uint32_t)BC_CCU8_STATUS_SUCCESS)
		{
			for (index = (uint8_t)0; index < BC_CCU8_MAXPHASE_COUNT; index++)
			{
				/* Phase configurations */
				XMC_CCU8_SLICE_CompareInit(HandlePtr->phase_ptr[index]->slice_ptr, HandlePtr->ph_timerinit_ptr);
				/* Update period registers */
				XMC_CCU8_SLICE_SetTimerPeriodMatch(HandlePtr->phase_ptr[index]->slice_ptr,HandlePtr->period);
				/* configure a slice trigger event*/
				XMC_CCU8_SLICE_ConfigureEvent(HandlePtr->phase_ptr[index]->slice_ptr,(XMC_CCU8_SLICE_EVENT_t)XMC_CCU8_SLICE_EVENT_0, HandlePtr->startconfig_ptr);
			}

			/* COM/ADC Trigger slice */
			XMC_CCU8_SLICE_CompareInit(HandlePtr->com_ptr->slice_ptr, HandlePtr->ph_timerinit_ptr);
			XMC_CCU8_SLICE_SetTimerPeriodMatch(HandlePtr->com_ptr->slice_ptr, HandlePtr->period);
			XMC_CCU8_SLICE_ConfigureEvent(HandlePtr->com_ptr->slice_ptr, (XMC_CCU8_SLICE_EVENT_t)XMC_CCU8_SLICE_EVENT_0, HandlePtr->startconfig_ptr);

			/* COM - Connect events to node */
			XMC_CCU8_SLICE_SetInterruptNode(HandlePtr->com_ptr->slice_ptr,
					                        (XMC_CCU8_SLICE_IRQ_ID_t)XMC_CCU8_SLICE_IRQ_ID_PERIOD_MATCH,
											(XMC_CCU8_SLICE_SR_ID_t)(HandlePtr->config_ptr->event_sr_selector & 0x03));
			XMC_CCU8_SLICE_EnableEvent(HandlePtr->com_ptr->slice_ptr,XMC_CCU8_SLICE_IRQ_ID_PERIOD_MATCH);

			NVIC_SetPriority(HandlePtr->int_com->node, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), HandlePtr->int_com->priority, HandlePtr->int_com->subpriority));
			NVIC_EnableIRQ(HandlePtr->int_com->node);

			/* ADC - Trigger - Connect events to node */
			XMC_CCU8_SLICE_SetInterruptNode(HandlePtr->com_ptr->slice_ptr,
											(XMC_CCU8_SLICE_IRQ_ID_t)XMC_CCU8_SLICE_IRQ_ID_COMPARE_MATCH_UP_CH_1,
											(XMC_CCU8_SLICE_SR_ID_t)((HandlePtr->config_ptr->event_sr_selector & 0x0C)>>2));
			XMC_CCU8_SLICE_EnableEvent(HandlePtr->com_ptr->slice_ptr,XMC_CCU8_SLICE_IRQ_ID_COMPARE_MATCH_UP_CH_1);

			XMC_CCU8_EnableClock(HandlePtr->module_ptr,HandlePtr->phase_ptr[0]->slice_number);
			XMC_CCU8_EnableClock(HandlePtr->module_ptr,HandlePtr->phase_ptr[1]->slice_number);
			XMC_CCU8_EnableClock(HandlePtr->module_ptr,HandlePtr->phase_ptr[2]->slice_number);
			XMC_CCU8_EnableClock(HandlePtr->module_ptr,HandlePtr->com_ptr->slice_number);

		    HandlePtr->dead_time_rising_edge     = (uint8_t)HandlePtr->deadtimeconfig_ptr->channel1_st_rising_edge_counter;
		    HandlePtr->dead_time_falling_edge    = (uint8_t)HandlePtr->deadtimeconfig_ptr->channel1_st_falling_edge_counter;

		    HandlePtr->deadtime_div  = (uint8_t)HandlePtr->deadtimeconfig_ptr->div;
		    HandlePtr->state          = BC_CCU8_INITIALIZED;
		}
		else
		{
			init_status = (uint32_t)BC_CCU8_STATUS_FAILURE;
		}
	}

	return ((BC_CCU8_STATUS_t)init_status);
}

/**
 * This function starts the CCU8 slices used to generate BC PWM.
 */
void BC_CCU8_Start(BC_CCU8_t* HandlePtr)
{
	uint8_t index;
	XMC_ASSERT("BC_CCU8_Start:NULL Handle Pointer",
			(HandlePtr != (BC_CCU8_t *)NULL));
	if ((BC_CCU8_INITIALIZED == HandlePtr->state) ||
		(BC_CCU8_STOPPED == HandlePtr->state))
	{
		XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phuh_cmpch, HandlePtr->compare);
		XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phul_cmpch, HandlePtr->compare);
		XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvh_cmpch, 0UL);
		XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvl_cmpch, 0UL);
		XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwh_cmpch, 0UL);
		XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwl_cmpch, HandlePtr->period+1);
		XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->com_ptr->slice_ptr, HandlePtr->config_ptr->com_cmpch, HandlePtr->compare>>1);

		XMC_CCU8_EnableShadowTransfer(HandlePtr->module_ptr,(uint32_t)HandlePtr->config_ptr->shadowtransfer_mask);

		/* configure the Start trigger function of a slice*/
		XMC_CCU8_SLICE_StartConfig(HandlePtr->phase_ptr[0]->slice_ptr,XMC_CCU8_SLICE_EVENT_0,
                       XMC_CCU8_SLICE_START_MODE_TIMER_START_CLEAR);
		XMC_CCU8_SLICE_StartConfig(HandlePtr->phase_ptr[1]->slice_ptr,XMC_CCU8_SLICE_EVENT_0,
                       XMC_CCU8_SLICE_START_MODE_TIMER_START_CLEAR);
		XMC_CCU8_SLICE_StartConfig(HandlePtr->phase_ptr[2]->slice_ptr,XMC_CCU8_SLICE_EVENT_0,
                       XMC_CCU8_SLICE_START_MODE_TIMER_START_CLEAR);
		XMC_CCU8_SLICE_StartConfig(HandlePtr->com_ptr->slice_ptr,XMC_CCU8_SLICE_EVENT_0,
		               XMC_CCU8_SLICE_START_MODE_TIMER_START_CLEAR);

		for (index = (uint8_t)0; index < BC_CCU8_MAXPHASE_COUNT; index++)
		{
			XMC_CCU8_SLICE_DeadTimeInit(HandlePtr->phase_ptr[index]->slice_ptr,HandlePtr->deadtimeconfig_ptr);
		}

		XMC_CCU8_SLICE_ConfigureDeadTime(HandlePtr->phase_ptr[0]->slice_ptr,HandlePtr->config_ptr->deadtime_control[0]);
		XMC_CCU8_SLICE_ConfigureDeadTime(HandlePtr->phase_ptr[1]->slice_ptr,HandlePtr->config_ptr->deadtime_control[1]);
		XMC_CCU8_SLICE_ConfigureDeadTime(HandlePtr->phase_ptr[2]->slice_ptr,HandlePtr->config_ptr->deadtime_control[2]);

		if (1U == HandlePtr->config_ptr->syncstart_enable)
		{
			/** Start CCU8 slices synchronously */
			XMC_SCU_SetCcuTriggerHigh((uint32_t)HandlePtr->config_ptr->syncstart_mask);
			/* Disable the Start trigger function of a slice*/
			XMC_CCU8_SLICE_StartConfig(HandlePtr->phase_ptr[0]->slice_ptr,(XMC_CCU8_SLICE_EVENT_t)XMC_CCU8_SLICE_EVENT_NONE,
                         	(XMC_CCU8_SLICE_START_MODE_t)XMC_CCU8_SLICE_START_MODE_TIMER_START_CLEAR);
			XMC_CCU8_SLICE_StartConfig(HandlePtr->phase_ptr[1]->slice_ptr,(XMC_CCU8_SLICE_EVENT_t)XMC_CCU8_SLICE_EVENT_NONE,
                         	(XMC_CCU8_SLICE_START_MODE_t)XMC_CCU8_SLICE_START_MODE_TIMER_START_CLEAR);
			XMC_CCU8_SLICE_StartConfig(HandlePtr->phase_ptr[2]->slice_ptr,(XMC_CCU8_SLICE_EVENT_t)XMC_CCU8_SLICE_EVENT_NONE,
							(XMC_CCU8_SLICE_START_MODE_t)XMC_CCU8_SLICE_START_MODE_TIMER_START_CLEAR);
			XMC_CCU8_SLICE_StartConfig(HandlePtr->com_ptr->slice_ptr,(XMC_CCU8_SLICE_EVENT_t)XMC_CCU8_SLICE_EVENT_NONE,
							(XMC_CCU8_SLICE_START_MODE_t)XMC_CCU8_SLICE_START_MODE_TIMER_START_CLEAR);

			/* disable synchronous start of CCU8 slices */
			XMC_SCU_SetCcuTriggerLow((uint32_t)HandlePtr->config_ptr->syncstart_mask);
		}

		HandlePtr->state = BC_CCU8_RAMP;
	}
}

/**
 * This function stops the CCU8 slices used to generate PWM.
 */
void BC_CCU8_Stop(BC_CCU8_t* HandlePtr)
{
	XMC_ASSERT("BC_CCU8_Stop:NULL Handle Pointer",
              (HandlePtr != (BC_CCU8_t *)NULL));

	XMC_CCU8_SLICE_StopTimer(HandlePtr->phase_ptr[0]->slice_ptr);
	XMC_CCU8_SLICE_ClearTimer(HandlePtr->phase_ptr[0]->slice_ptr);
	XMC_CCU8_SLICE_StopTimer(HandlePtr->phase_ptr[1]->slice_ptr);
	XMC_CCU8_SLICE_ClearTimer(HandlePtr->phase_ptr[1]->slice_ptr);
	XMC_CCU8_SLICE_StopTimer(HandlePtr->phase_ptr[2]->slice_ptr);
	XMC_CCU8_SLICE_ClearTimer(HandlePtr->phase_ptr[2]->slice_ptr);
	XMC_CCU8_SLICE_StopTimer(HandlePtr->com_ptr->slice_ptr);
	XMC_CCU8_SLICE_ClearTimer(HandlePtr->com_ptr->slice_ptr);

	HandlePtr->pattern=0;
	HandlePtr->com_cnt=0;
	HandlePtr->ramp_cnt=0;
	HandlePtr->com_div=HandlePtr->speed_start_div;
	HandlePtr->compare = HandlePtr->compare_start;

	HandlePtr->state = BC_CCU8_STOPPED;
}

/* This API applies next commutation pattern */
void BC_CCU8_lCommutationEventHandler(BC_CCU8_t* const HandlePtr)
{
	if (HandlePtr->com_ptr->slice_ptr->INTS & CCU8_CC8_INTS_PMUS_Msk)
	{
		switch(HandlePtr->state)
		{
			case BC_CCU8_RAMP:
				HandlePtr->com_cnt++;

				if (HandlePtr->com_cnt % HandlePtr->com_div == 0)
				{
					BC_CCU8_lSetNextCommutationPattern(HandlePtr);
					HandlePtr->com_cnt=0;
				}

				HandlePtr->ramp_cnt++;
				if (HandlePtr->ramp_cnt % HandlePtr->speed_start_div == 0)
				{
					if (HandlePtr->com_div > HandlePtr->speed_end_div)
						HandlePtr->com_div--;
					else
					{
						HandlePtr->state = BC_CCU8_RUNNING;
						HandlePtr->com_cnt=HandlePtr->speed_end_div;
					}
					HandlePtr->ramp_cnt=0;
				}
				break;

			case BC_CCU8_RUNNING:

				if (HandlePtr->zerocrossing_ptr->crossing_detected)
					HandlePtr->com_cnt--;
				else
					HandlePtr->com_cnt++;

				if (HandlePtr->com_cnt==0)
					BC_CCU8_lSetNextCommutationPattern(HandlePtr);

				break;
			default:
				break;
		}

		HandlePtr->com_ptr->slice_ptr->SWR |= ((1 << CCU8_CC8_SWR_RPM_Pos) & CCU8_CC8_SWR_RPM_Msk);
	}
}

/* This API applies next commutation pattern */
void BC_CCU8_lSetNextCommutationPattern(BC_CCU8_t* const HandlePtr)
{
	HandlePtr->pattern++;
	if (HandlePtr->pattern > 5)
		HandlePtr->pattern=0;

	switch (HandlePtr->pattern)
	{
		case 0:
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phuh_cmpch, HandlePtr->compare);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phul_cmpch, HandlePtr->compare);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvh_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvl_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwh_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwl_cmpch, HandlePtr->period+1);
			break;
		case 1:
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phuh_cmpch, HandlePtr->compare);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phul_cmpch, HandlePtr->compare);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvh_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvl_cmpch, HandlePtr->period+1);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwh_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwl_cmpch, 0);
			break;
		case 2:
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phuh_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phul_cmpch, HandlePtr->period+1);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvh_cmpch, HandlePtr->compare);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvl_cmpch, HandlePtr->compare);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwh_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwl_cmpch, 0);
			break;
		case 3:
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phuh_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phul_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvh_cmpch, HandlePtr->compare);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvl_cmpch, HandlePtr->compare);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwh_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwl_cmpch, HandlePtr->period+1);
			break;
		case 4:
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phuh_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phul_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvh_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvl_cmpch, HandlePtr->period+1);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwh_cmpch, HandlePtr->compare);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwl_cmpch, HandlePtr->compare);
			break;
		case 5:
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phuh_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->config_ptr->phul_cmpch, HandlePtr->period+1);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvh_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->config_ptr->phvl_cmpch, 0);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwh_cmpch, HandlePtr->compare);
			XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->config_ptr->phwl_cmpch, HandlePtr->compare);
			break;
	}

	XMC_CCU8_SLICE_SetTimerCompareMatch(HandlePtr->com_ptr->slice_ptr, HandlePtr->config_ptr->com_cmpch, HandlePtr->compare>>1);

	XMC_CCU8_EnableShadowTransfer(HandlePtr->module_ptr,(uint32_t)HandlePtr->config_ptr->shadowtransfer_mask);

	HandlePtr->zerocrossing_ptr->pattern=HandlePtr->pattern;
	HandlePtr->zerocrossing_ptr->crossing_detected=0;
	HandlePtr->zerocrossing_ptr->disable_cnt=2;
}

void BC_CCU8_SetMotorSpeedPercent(BC_CCU8_t* const HandlePtr, float speed)
{
	if (speed > 100.0)
		speed = 100.0;

	HandlePtr->compare = speed/100.0 * (HandlePtr->period+1);
}
