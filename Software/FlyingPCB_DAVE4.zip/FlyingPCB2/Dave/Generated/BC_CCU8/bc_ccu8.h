#ifndef BC_CCU8_H_
#define BC_CCU8_H_
/***********************************************************************************************************************
 * HEADER FILES
 **********************************************************************************************************************/

#include <xmc_ccu8.h>
#include "xmc_scu.h"
#include <xmc_gpio.h>
#include <DAVE_common.h>
#include "../GLOBAL_CCU8/global_ccu8.h"
#include "../ZEROCROSSING/zerocrossing.h"
#include "bc_ccu8_conf.h"

#if (!((XMC_LIB_MAJOR_VERSION == 2U) && \
       (XMC_LIB_MINOR_VERSION >= 0U) && \
       (XMC_LIB_PATCH_VERSION >= 0U)))
#error "BC_CCU8 requires XMC Peripheral Library v2.0.0 or higher"
#endif


/**
 * @ingroup BC_CCU8_constants
 * @{
 */
/***********************************************************************************************************************
 * MACROS
 **********************************************************************************************************************/
#define BC_CCU8_MAXPHASE_COUNT    (3U)

/**
 * @}
 */

 /**********************************************************************************************************************
 * ENUMS
 **********************************************************************************************************************/
 /**
  * @ingroup BC_CCU8_enumerations
  * @{
  */

/**
 * State of the APP
 */

typedef enum BC_CCU8_STATE
{
	BC_CCU8_UNINITIALIZED,              /*!<default state after power on reset. APP goes to UNINITIALIZED state after execution of the Deinit function.*/
	BC_CCU8_INITIALIZED,                /*!<APP is in INITIALIZED state after execution of the Init function*/
	BC_CCU8_RAMP,						/*!<APP is in RUNNING state after execution of the Start function.*/
	BC_CCU8_RUNNING,                    /*!<APP is in RUNNING state after transition to zerocrossing detection has occured.*/
	BC_CCU8_STOPPED                     /*!<APP is in STOPPED state after execution of the Stop function.*/
}BC_CCU8_STATE_t;

/**
 * Status of the APP which can be occured during initialization.
 */
typedef enum BC_CCU8_STATUS
{
	BC_CCU8_STATUS_SUCCESS,              /*!< APP status ok*/
	BC_CCU8_STATUS_FAILURE,              /*!< APP status failure*/
	BC_CCU8_INVALID_PARAM,               /*!< Input parameter is out of range.*/
	BC_CCU8_OPERATION_NOT_ALLOWED        /*!< Operation is not allowed in the current state of the APP */
} BC_CCU8_STATUS_t;

/**
 * @}
 */

/**********************************************************************************************************************
* DATA STRUCTURES
**********************************************************************************************************************/
/**
  * @ingroup BC_CCU8_datastructures
  * @{
  */

/**
 * GPIO Port and Pin
 */
typedef struct BC_CCU8_GPIO
{
	XMC_GPIO_PORT_t *const port;      /**< Port */
	const uint8_t pin;                /**< Pin */
} BC_CCU8_GPIO_t;

/**
 *  CCU8-CC8 slice identifier data
 */
typedef struct BC_CCU8_SLICE
{
	XMC_CCU8_SLICE_t  *slice_ptr;     /**< CCU8 CC8 pointer */
	uint8_t            slice_number;  /**< The slice identifier - 0 index based*/
} BC_CCU8_SLICE_t;

/**
 * Interrupt configuration
 */
typedef struct BC_CCU8_INTERRUPT
{
	const IRQn_Type node;       	/**< Mapped NVIC Node */
	const uint8_t priority; 	  	/**< Node Interrupt Priority */
	const uint8_t subpriority;  	/**< Node Interrupt SubPriority only valid for XMC4x */
} BC_CCU8_INTERRUPT_t;

/**
 * This structure holds the GUI configurable parameters of this APP.
 */
typedef struct BC_CCU8_Config
{
	uint32_t                               module_freq;            /*!< Represents module frequency*/
	uint32_t                               syncstart_mask;         /*!< Synchronous start mask as per CCU8 slices allocated*/
	uint32_t                               event_sr_selector; 	   /*!< mask for the SRS register*/
	XMC_CCU8_SLICE_COMPARE_CHANNEL_t       phuh_cmpch;              /*!< Phase UH compare channel */
	XMC_CCU8_SLICE_COMPARE_CHANNEL_t       phvh_cmpch;              /*!< Phase VH compare channel */
	XMC_CCU8_SLICE_COMPARE_CHANNEL_t       phwh_cmpch;              /*!< Phase WH compare channel */
	XMC_CCU8_SLICE_COMPARE_CHANNEL_t       phul_cmpch;              /*!< Phase UL compare channel */
	XMC_CCU8_SLICE_COMPARE_CHANNEL_t       phvl_cmpch;              /*!< Phase VL compare channel */
	XMC_CCU8_SLICE_COMPARE_CHANNEL_t       phwl_cmpch;              /*!< Phase WL compare channel */
	XMC_CCU8_SLICE_COMPARE_CHANNEL_t       com_cmpch;              /*!< Commutation compare channel */
	uint16_t                               shadowtransfer_mask;    /*!< Shadow transfer mask as per CCU8 slices allocated*/
	uint8_t                                deadtime_control[3];    /*!< Mask for dead time feature for each phase */
	uint8_t                                syncstart_enable;       /*!< This enables/disables synchronous start of ccu8 slices*/

}BC_CCU8_Config_t;

/**
  * This structure holds the BC parameters which change at run
  * time.
  */
typedef struct BC_CCU8
{
			XMC_CCU8_MODULE_t*                         	const  	module_ptr;         	/*!< CCU8 module initialization structure pointer*/
	const	BC_CCU8_SLICE_t*                     		const  	phase_ptr[3];         	/*!< Pointer to ccu8 phase timer init configuration structure*/
	const	BC_CCU8_SLICE_t*                     		const  	com_ptr;         		/*!< Pointer to ccu8 com timer init configuration structure*/
			GLOBAL_CCU8_t*							 	const	globalccu8_ptr;			/*!< Pointer to the GLOBAL_CCU8 APP handle structure*/
			ZEROCROSSING_t*								const	zerocrossing_ptr;		/*!< Pointer to the ZEROCROSSING APP handle structure*/
	const  	XMC_CCU8_SLICE_EVENT_CONFIG_t*      		const  	startconfig_ptr;      	/*!< Pointer to start event configuration structure*/
	const  	XMC_CCU8_SLICE_COMPARE_CONFIG_t*    		const  	ph_timerinit_ptr;     	/*!< CCU8 timer init structure pointer */
	const	BC_CCU8_GPIO_t*								const	pwmoutpin_ptr[6];		/*!< GPIO pin initialization structure pointer for PWM pins*/
	const	XMC_GPIO_CONFIG_t*  		                const	pwmoutconfig_ptr[6];  	/*!< GPIO pin configuration structure pointer for PWM pins */
			BC_CCU8_STATE_t										state;					/*!< State of the APP */
	const  	BC_CCU8_Config_t*                    		const  	config_ptr;           	/*!< pointer to the Dynamic Handle of the APP */
			XMC_CCU8_SLICE_DEAD_TIME_CONFIG_t*  		const  	deadtimeconfig_ptr;   	/*!< Pointer to Dead time configuration structure*/
	const   BC_CCU8_INTERRUPT_t*						const	int_com;				/*!< Pointer to commutation intterupt */
			uint16_t   			                                period;    		        /*!< This variable gives the period value*/
			uint16_t											compare;				/*!< This variable gives the compare value*/
			uint16_t											compare_start;
			uint8_t												pattern;
	        uint8_t                                    			deadtime_div;           /*!< Deadtime prescaler value*/
	        uint8_t                                    			dead_time_rising_edge;  /*!< Deadtime register value*/
	        uint8_t                                    			dead_time_falling_edge; /*!< Deadtime register value*/
	        uint16_t											speed_start_div;		/*!< Divider for start rampup speed*/
	        uint16_t											speed_end_div;			/*!< Divider for end rampup speed*/
	        uint16_t											com_div;				/*!< Divider for commutation*/
	        uint16_t											com_cnt;				/*!< counts commutation patterns*/
	        uint16_t											ramp_cnt;				/*!< ramp counter*/
}BC_CCU8_t;

/**
 * @}
 */

#ifdef __cplusplus
extern "C" {
#endif
/**
 * @ingroup BC_CCU8_apidoc
 * @{
 */
  /***********************************************************************************************************************
   * API Prototypes
   **********************************************************************************************************************/

DAVE_APP_VERSION_t BC_CCU8_GetAppVersion(void);
BC_CCU8_STATUS_t BC_CCU8_Init(BC_CCU8_t* HandlePtr);

void BC_CCU8_Start(BC_CCU8_t* HandlePtr);
void BC_CCU8_Stop(BC_CCU8_t* HandlePtr);
void BC_CCU8_SetMotorSpeedPercent(BC_CCU8_t* const HandlePtr, float speed);

void BC_CCU8_lSetNextCommutationPattern(BC_CCU8_t* const HandlePtr);
void BC_CCU8_lCommutationEventHandler(BC_CCU8_t* const HandlePtr);

/**
 * @}
 */

#include "bc_ccu8_extern.h"

#ifdef __cplusplus
}
#endif

#endif /* BC_CCU8_H_ */

