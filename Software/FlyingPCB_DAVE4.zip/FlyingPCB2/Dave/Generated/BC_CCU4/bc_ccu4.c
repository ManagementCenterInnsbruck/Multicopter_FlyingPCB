/***********************************************************************************************************************
 * HEADER FILES
 **********************************************************************************************************************/
#include "bc_ccu4.h"

/***********************************************************************************************************************
 * MACROS
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * LOCAL DATA
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * LOCAL ROUTINES
 **********************************************************************************************************************/

/* Initialization of the GPIO */
void BC_CCU4_lPinInit(BC_CCU4_t* const HandlePtr)
{
	XMC_ASSERT("BC_CCU4_lPinInit:NULL Handle Pointer", (HandlePtr != (BC_CCU4_t *)NULL));

	XMC_GPIO_Init(HandlePtr->pwmoutpin_ptr[0]->port,HandlePtr->pwmoutpin_ptr[0]->pin, HandlePtr->pwmoutconfig_ptr[0]);
	XMC_GPIO_Init(HandlePtr->pwmoutpin_ptr[1]->port,HandlePtr->pwmoutpin_ptr[1]->pin, HandlePtr->pwmoutconfig_ptr[1]);
	XMC_GPIO_Init(HandlePtr->pwmoutpin_ptr[2]->port,HandlePtr->pwmoutpin_ptr[2]->pin, HandlePtr->pwmoutconfig_ptr[2]);
	XMC_GPIO_Init(HandlePtr->pwmoutpin_ptr[3]->port,HandlePtr->pwmoutpin_ptr[3]->pin, HandlePtr->pwmoutconfig_ptr[3]);
	XMC_GPIO_Init(HandlePtr->pwmoutpin_ptr[4]->port,HandlePtr->pwmoutpin_ptr[4]->pin, HandlePtr->pwmoutconfig_ptr[4]);
	XMC_GPIO_Init(HandlePtr->pwmoutpin_ptr[5]->port,HandlePtr->pwmoutpin_ptr[5]->pin, HandlePtr->pwmoutconfig_ptr[5]);
}

/* App API to retrieve the App version info */
DAVE_APP_VERSION_t BC_CCU4_GetAppVersion(void)
{
	DAVE_APP_VERSION_t version;

	version.major = BC_CCU4_MAJOR_VERSION;
	version.minor = BC_CCU4_MINOR_VERSION;
	version.patch = BC_CCU4_PATCH_VERSION;

	return version;
}

/**
 * This function initializes all the three CCU4 phases as per the user configurations
 */
BC_CCU4_STATUS_t BC_CCU4_Init(BC_CCU4_t* HandlePtr)
{
	uint8_t index;
	uint32_t init_status = (uint32_t)BC_CCU4_STATUS_SUCCESS;

	XMC_ASSERT("BC_CCU4_Init:NULL Handle Pointer",
				(HandlePtr != (BC_CCU4_t *)NULL));

	if (BC_CCU4_UNINITIALIZED == HandlePtr->state)
	{
		/* CCU4 global init to start the prescalar and de-assert the module */
		init_status  =  (uint32_t)GLOBAL_CCU4_Init(HandlePtr->globalccu4_uv_ptr);
		init_status  |= (uint32_t)GLOBAL_CCU4_Init(HandlePtr->globalccu4_w_ptr);
		init_status |= (uint32_t)ZEROCROSSING_Init(HandlePtr->zerocrossing_ptr);
		BC_CCU4_lPinInit(HandlePtr);

		if (init_status == (uint32_t)BC_CCU4_STATUS_SUCCESS)
		{
			for (index = (uint8_t)0; index < BC_CCU4_MAXPHASE_COUNT; index++)
			{
				/* Phase configurations */
				if (index % 2 == 0)
					XMC_CCU4_SLICE_CompareInit(HandlePtr->phase_ptr[index]->slice_ptr, HandlePtr->ph_timerinit_high_ptr);
				else
					XMC_CCU4_SLICE_CompareInit(HandlePtr->phase_ptr[index]->slice_ptr, HandlePtr->ph_timerinit_low_ptr);
				/* Update period registers */
				XMC_CCU4_SLICE_SetTimerPeriodMatch(HandlePtr->phase_ptr[index]->slice_ptr,HandlePtr->period);
				/* configure a slice trigger event*/
				XMC_CCU4_SLICE_ConfigureEvent(HandlePtr->phase_ptr[index]->slice_ptr,(XMC_CCU4_SLICE_EVENT_t)XMC_CCU4_SLICE_EVENT_0, HandlePtr->startconfig_ptr);
			}

			/* ADC Trigger slice */
			XMC_CCU4_SLICE_CompareInit(HandlePtr->com_ptr->slice_ptr, HandlePtr->ph_timerinit_low_ptr);
			XMC_CCU4_SLICE_SetTimerPeriodMatch(HandlePtr->com_ptr->slice_ptr, HandlePtr->period);
			XMC_CCU4_SLICE_ConfigureEvent(HandlePtr->com_ptr->slice_ptr, (XMC_CCU4_SLICE_EVENT_t)XMC_CCU4_SLICE_EVENT_0, HandlePtr->startconfig_ptr);

			/* COM - Connect events to node */
			XMC_CCU4_SLICE_SetInterruptNode(HandlePtr->com_ptr->slice_ptr,
					                        (XMC_CCU4_SLICE_IRQ_ID_t)XMC_CCU4_SLICE_IRQ_ID_PERIOD_MATCH,
											(XMC_CCU4_SLICE_SR_ID_t)(HandlePtr->config_ptr->event_sr_selector & 0x03));
			XMC_CCU4_SLICE_EnableEvent(HandlePtr->com_ptr->slice_ptr,XMC_CCU4_SLICE_IRQ_ID_PERIOD_MATCH);

			NVIC_SetPriority(HandlePtr->int_com->node, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), HandlePtr->int_com->priority, HandlePtr->int_com->subpriority));
			NVIC_EnableIRQ(HandlePtr->int_com->node);

			/* ADC - Trigger - Connect events to node */
			XMC_CCU4_SLICE_SetInterruptNode(HandlePtr->com_ptr->slice_ptr,
					                        (XMC_CCU4_SLICE_IRQ_ID_t)XMC_CCU4_SLICE_IRQ_ID_COMPARE_MATCH_UP,
											(XMC_CCU4_SLICE_SR_ID_t)(((HandlePtr->config_ptr->event_sr_selector) & 0x0C)>>2));
			XMC_CCU4_SLICE_EnableEvent(HandlePtr->com_ptr->slice_ptr,XMC_CCU4_SLICE_IRQ_ID_COMPARE_MATCH_DOWN);

			XMC_CCU4_EnableClock(HandlePtr->phase_ptr[0]->module_ptr,HandlePtr->phase_ptr[0]->slice_number);
			XMC_CCU4_EnableClock(HandlePtr->phase_ptr[1]->module_ptr,HandlePtr->phase_ptr[1]->slice_number);
			XMC_CCU4_EnableClock(HandlePtr->phase_ptr[2]->module_ptr,HandlePtr->phase_ptr[2]->slice_number);
			XMC_CCU4_EnableClock(HandlePtr->phase_ptr[3]->module_ptr,HandlePtr->phase_ptr[3]->slice_number);
			XMC_CCU4_EnableClock(HandlePtr->phase_ptr[4]->module_ptr,HandlePtr->phase_ptr[4]->slice_number);
			XMC_CCU4_EnableClock(HandlePtr->phase_ptr[5]->module_ptr,HandlePtr->phase_ptr[5]->slice_number);
			XMC_CCU4_EnableClock(HandlePtr->phase_ptr[6]->module_ptr,HandlePtr->com_ptr->slice_number);

		    HandlePtr->state          = BC_CCU4_INITIALIZED;
		}
		else
		{
			init_status = (uint32_t)BC_CCU4_STATUS_FAILURE;
		}
	}

	return ((BC_CCU4_STATUS_t)init_status);
}

/**
 * This function starts the CCU4 slices used to generate BC PWM.
 */
void BC_CCU4_Start(BC_CCU4_t* HandlePtr)
{
	XMC_ASSERT("BC_CCU4_Start:NULL Handle Pointer",
			(HandlePtr != (BC_CCU4_t *)NULL));
	if ((BC_CCU4_INITIALIZED == HandlePtr->state) ||
		(BC_CCU4_STOPPED == HandlePtr->state))
	{
		XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->compare);
		XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->compare-HandlePtr->dead_time);
		XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, 0UL);
		XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[3]->slice_ptr, 0UL);
		XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[4]->slice_ptr, 0UL);
		XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[5]->slice_ptr, HandlePtr->period+1);
		XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->com_ptr->slice_ptr, 1);

		XMC_CCU4_EnableShadowTransfer(HandlePtr->phase_ptr[0]->module_ptr,(uint32_t)HandlePtr->config_ptr->shadowtransfer_mask_uv);
		XMC_CCU4_EnableShadowTransfer(HandlePtr->phase_ptr[4]->module_ptr,(uint32_t)HandlePtr->config_ptr->shadowtransfer_mask_w);

		/* configure the Start trigger function of a slice*/
		XMC_CCU4_SLICE_StartConfig(HandlePtr->phase_ptr[0]->slice_ptr,XMC_CCU4_SLICE_EVENT_0,
                       XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);
		XMC_CCU4_SLICE_StartConfig(HandlePtr->phase_ptr[1]->slice_ptr,XMC_CCU4_SLICE_EVENT_0,
                       XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);
		XMC_CCU4_SLICE_StartConfig(HandlePtr->phase_ptr[2]->slice_ptr,XMC_CCU4_SLICE_EVENT_0,
                       XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);
		XMC_CCU4_SLICE_StartConfig(HandlePtr->phase_ptr[3]->slice_ptr,XMC_CCU4_SLICE_EVENT_0,
                       XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);
		XMC_CCU4_SLICE_StartConfig(HandlePtr->phase_ptr[4]->slice_ptr,XMC_CCU4_SLICE_EVENT_0,
                       XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);
		XMC_CCU4_SLICE_StartConfig(HandlePtr->phase_ptr[5]->slice_ptr,XMC_CCU4_SLICE_EVENT_0,
                       XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);
		XMC_CCU4_SLICE_StartConfig(HandlePtr->com_ptr->slice_ptr,XMC_CCU4_SLICE_EVENT_0,
		               XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);

		if (1U == HandlePtr->config_ptr->syncstart_enable)
		{
			/** Start CCU4 slices synchronously */
			XMC_SCU_SetCcuTriggerHigh((uint32_t)HandlePtr->config_ptr->syncstart_mask);
			/* Disable the Start trigger function of a slice*/
			XMC_CCU4_SLICE_StartConfig(HandlePtr->phase_ptr[0]->slice_ptr,(XMC_CCU4_SLICE_EVENT_t)XMC_CCU4_SLICE_EVENT_NONE,
                         	(XMC_CCU4_SLICE_START_MODE_t)XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);
			XMC_CCU4_SLICE_StartConfig(HandlePtr->phase_ptr[1]->slice_ptr,(XMC_CCU4_SLICE_EVENT_t)XMC_CCU4_SLICE_EVENT_NONE,
                         	(XMC_CCU4_SLICE_START_MODE_t)XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);
			XMC_CCU4_SLICE_StartConfig(HandlePtr->phase_ptr[2]->slice_ptr,(XMC_CCU4_SLICE_EVENT_t)XMC_CCU4_SLICE_EVENT_NONE,
							(XMC_CCU4_SLICE_START_MODE_t)XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);
			XMC_CCU4_SLICE_StartConfig(HandlePtr->phase_ptr[3]->slice_ptr,(XMC_CCU4_SLICE_EVENT_t)XMC_CCU4_SLICE_EVENT_NONE,
							(XMC_CCU4_SLICE_START_MODE_t)XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);
			XMC_CCU4_SLICE_StartConfig(HandlePtr->phase_ptr[4]->slice_ptr,(XMC_CCU4_SLICE_EVENT_t)XMC_CCU4_SLICE_EVENT_NONE,
							(XMC_CCU4_SLICE_START_MODE_t)XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);
			XMC_CCU4_SLICE_StartConfig(HandlePtr->phase_ptr[5]->slice_ptr,(XMC_CCU4_SLICE_EVENT_t)XMC_CCU4_SLICE_EVENT_NONE,
							(XMC_CCU4_SLICE_START_MODE_t)XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);
			XMC_CCU4_SLICE_StartConfig(HandlePtr->com_ptr->slice_ptr,(XMC_CCU4_SLICE_EVENT_t)XMC_CCU4_SLICE_EVENT_NONE,
							(XMC_CCU4_SLICE_START_MODE_t)XMC_CCU4_SLICE_START_MODE_TIMER_START_CLEAR);

			/* disable synchronous start of CCU4 slices */
			XMC_SCU_SetCcuTriggerLow((uint32_t)HandlePtr->config_ptr->syncstart_mask);
		}

		HandlePtr->state = BC_CCU4_RAMP;
	}
}

/**
 * This function stops the CCU4 slices used to generate PWM.
 */
void BC_CCU4_Stop(BC_CCU4_t* HandlePtr)
{
	XMC_ASSERT("BC_CCU4_Stop:NULL Handle Pointer",
              (HandlePtr != (BC_CCU4_t *)NULL));

	/* stop all slices */
	XMC_CCU4_SLICE_StopTimer(HandlePtr->phase_ptr[0]->slice_ptr);
	XMC_CCU4_SLICE_ClearTimer(HandlePtr->phase_ptr[0]->slice_ptr);
	XMC_CCU4_SLICE_StopTimer(HandlePtr->phase_ptr[1]->slice_ptr);
	XMC_CCU4_SLICE_ClearTimer(HandlePtr->phase_ptr[1]->slice_ptr);
	XMC_CCU4_SLICE_StopTimer(HandlePtr->phase_ptr[2]->slice_ptr);
	XMC_CCU4_SLICE_ClearTimer(HandlePtr->phase_ptr[2]->slice_ptr);
	XMC_CCU4_SLICE_StopTimer(HandlePtr->phase_ptr[3]->slice_ptr);
	XMC_CCU4_SLICE_ClearTimer(HandlePtr->phase_ptr[3]->slice_ptr);
	XMC_CCU4_SLICE_StopTimer(HandlePtr->phase_ptr[4]->slice_ptr);
	XMC_CCU4_SLICE_ClearTimer(HandlePtr->phase_ptr[4]->slice_ptr);
	XMC_CCU4_SLICE_StopTimer(HandlePtr->phase_ptr[5]->slice_ptr);
	XMC_CCU4_SLICE_ClearTimer(HandlePtr->phase_ptr[5]->slice_ptr);
	XMC_CCU4_SLICE_StopTimer(HandlePtr->com_ptr->slice_ptr);
	XMC_CCU4_SLICE_ClearTimer(HandlePtr->com_ptr->slice_ptr);

	HandlePtr->pattern=0;
	HandlePtr->com_cnt=0;
	HandlePtr->ramp_cnt=0;
	HandlePtr->com_div=HandlePtr->speed_start_div;
	HandlePtr->compare=HandlePtr->compare_start;

	HandlePtr->state = BC_CCU4_STOPPED;
}

/* This API applies next commutation pattern */
void BC_CCU4_lSetNextCommutationPattern(BC_CCU4_t* const HandlePtr)
{
	HandlePtr->pattern++;
	if (HandlePtr->pattern > 5)
		HandlePtr->pattern=0;

	switch (HandlePtr->pattern)
	{
		case 0:
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->compare);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->compare+HandlePtr->dead_time);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[3]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[4]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[5]->slice_ptr, HandlePtr->period+1);
			break;
		case 1:
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, HandlePtr->compare);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->compare+HandlePtr->dead_time);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[3]->slice_ptr, HandlePtr->period+1);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[4]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[5]->slice_ptr, 0);
			break;
		case 2:
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->period+1);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->compare);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[3]->slice_ptr, HandlePtr->compare+HandlePtr->dead_time);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[4]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[5]->slice_ptr, 0);
			break;
		case 3:
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, HandlePtr->compare);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[3]->slice_ptr, HandlePtr->compare+HandlePtr->dead_time);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[4]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[5]->slice_ptr, HandlePtr->period+1);
			break;
		case 4:
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[3]->slice_ptr, HandlePtr->period+1);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[4]->slice_ptr, HandlePtr->compare);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[5]->slice_ptr, HandlePtr->compare+HandlePtr->dead_time);
			break;
		default:
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[0]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[1]->slice_ptr, HandlePtr->period+1);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[2]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[3]->slice_ptr, 0);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[4]->slice_ptr, HandlePtr->compare);
			XMC_CCU4_SLICE_SetTimerCompareMatch(HandlePtr->phase_ptr[5]->slice_ptr, HandlePtr->compare+HandlePtr->dead_time);
			break;
	}

	XMC_CCU4_EnableShadowTransfer(HandlePtr->phase_ptr[0]->module_ptr, (uint32_t)HandlePtr->config_ptr->shadowtransfer_mask_uv);
	XMC_CCU4_EnableShadowTransfer(HandlePtr->phase_ptr[4]->module_ptr, (uint32_t)HandlePtr->config_ptr->shadowtransfer_mask_w);

	HandlePtr->zerocrossing_ptr->pattern=HandlePtr->pattern;
	HandlePtr->zerocrossing_ptr->crossing_detected=0;
	HandlePtr->zerocrossing_ptr->disable_cnt=2;
}

void BC_CCU4_lCommutationEventHandler(BC_CCU4_t* const HandlePtr)
{
	if (HandlePtr->com_ptr->slice_ptr->INTS & CCU4_CC4_INTS_PMUS_Msk)
	{
		switch(HandlePtr->state)
		{
			case BC_CCU4_RAMP:

				HandlePtr->com_cnt++;

				if (HandlePtr->com_cnt % HandlePtr->com_div == 0)
				{
					BC_CCU4_lSetNextCommutationPattern(HandlePtr);
					HandlePtr->com_cnt=0;
				}

				HandlePtr->ramp_cnt++;
				if (HandlePtr->ramp_cnt % HandlePtr->speed_start_div == 0)
				{
					if (HandlePtr->com_div > HandlePtr->speed_end_div)
						HandlePtr->com_div--;
					else
					{
						HandlePtr->state = BC_CCU4_RUNNING;
						HandlePtr->com_cnt=HandlePtr->speed_end_div;
					}
					HandlePtr->ramp_cnt=0;
				}
				break;

			case BC_CCU4_RUNNING:

				if (HandlePtr->zerocrossing_ptr->crossing_detected)
					HandlePtr->com_cnt--;
				else
					HandlePtr->com_cnt++;

				if (HandlePtr->com_cnt==0)
					BC_CCU4_lSetNextCommutationPattern(HandlePtr);
				break;

			default:
				break;
		}
		HandlePtr->com_ptr->slice_ptr->SWR |= ((1 << CCU4_CC4_SWR_RPM_Pos) & CCU4_CC4_SWR_RPM_Msk);
	}
}

void BC_CCU4_SetMotorSpeedPercent(BC_CCU4_t* const HandlePtr, float speed)
{
	if (speed > 100.0)
		speed = 100.0;

	HandlePtr->compare = speed/100.0 * (HandlePtr->period+1);
}
