#ifndef BC_CCU4_H_
#define BC_CCU4_H_
/***********************************************************************************************************************
 * HEADER FILES
 **********************************************************************************************************************/

#include <xmc_ccu4.h>
#include "xmc_scu.h"
#include <xmc_gpio.h>
#include <DAVE_common.h>
#include "../GLOBAL_CCU4/global_ccu4.h"
#include "../ZEROCROSSING/zerocrossing.h"
#include "bc_ccu4_conf.h"

#if (!((XMC_LIB_MAJOR_VERSION == 2U) && \
       (XMC_LIB_MINOR_VERSION >= 0U) && \
       (XMC_LIB_PATCH_VERSION >= 0U)))
#error "BC_CCU4 requires XMC Peripheral Library v2.0.0 or higher"
#endif


/**
 * @ingroup BC_CCU4_constants
 * @{
 */
/***********************************************************************************************************************
 * MACROS
 **********************************************************************************************************************/
#define BC_CCU4_MAXPHASE_COUNT    (6U)

/**
 * @}
 */

 /**********************************************************************************************************************
 * ENUMS
 **********************************************************************************************************************/
 /**
  * @ingroup BC_CCU4_enumerations
  * @{
  */

/**
 * State of the APP
 */

typedef enum BC_CCU4_STATE
{
	BC_CCU4_UNINITIALIZED,              /*!<default state after power on reset. APP goes to UNINITIALIZED state after execution of the Deinit function.*/
	BC_CCU4_INITIALIZED,                /*!<APP is in INITIALIZED state after execution of the Init function*/
	BC_CCU4_RAMP,						/*!<APP is in RUNNING state after execution of the Start function.*/
	BC_CCU4_RUNNING,                    /*!<APP is in RUNNING state after execution of the Start function.*/
	BC_CCU4_STOPPED                     /*!<APP is in STOPPED state after execution of the Stop function.*/
}BC_CCU4_STATE_t;

/**
 * Status of the APP which can be occured during initialization.
 */
typedef enum BC_CCU4_STATUS
{
	BC_CCU4_STATUS_SUCCESS,              /*!< APP status ok*/
	BC_CCU4_STATUS_FAILURE,              /*!< APP status failure*/
	BC_CCU4_INVALID_PARAM,               /*!< Input parameter is out of range.*/
	BC_CCU4_OPERATION_NOT_ALLOWED        /*!< Operation is not allowed in the current state of the APP */
} BC_CCU4_STATUS_t;

/**
 * @}
 */

/**********************************************************************************************************************
* DATA STRUCTURES
**********************************************************************************************************************/
/**
  * @ingroup BC_CCU4_datastructures
  * @{
  */

/**
 * GPIO Port and Pin
 */
typedef struct BC_CCU4_GPIO
{
	XMC_GPIO_PORT_t *const port;      /**< Port */
	const uint8_t pin;                /**< Pin */
} BC_CCU4_GPIO_t;

/**
 *  CCU4-CC4 slice identifier data
 */
typedef struct BC_CCU4_SLICE
{
	XMC_CCU4_MODULE_t               *module_ptr;   /*!< CCU4 module initialization structure pointer*/
	XMC_CCU4_SLICE_t  				*slice_ptr;    /**< CCU4 CC4 pointer */
	uint8_t            				slice_number;  /**< The slice identifier - 0 index based*/
} BC_CCU4_SLICE_t;

/**
 * Interrupt configuration
 */
typedef struct BC_CCU4_INTERRUPT
{
	const IRQn_Type node;       	/**< Mapped NVIC Node */
	const uint8_t priority; 	  	/**< Node Interrupt Priority */
	const uint8_t subpriority;  	/**< Node Interrupt SubPriority only valid for XMC4x */
} BC_CCU4_INTERRUPT_t;

/**
 * This structure holds the GUI configurable parameters of this APP.
 */
typedef struct BC_CCU4_Config
{
	uint32_t                               module_freq;            /*!< Represents module frequency*/
	uint32_t                               syncstart_mask;         /*!< Synchronous start mask as per CCU4 slices allocated*/
	uint32_t                               event_sr_selector; 	   /*!< mask for the SRS register*/
	uint16_t                               shadowtransfer_mask_uv; /*!< Shadow transfer mask as per CCU4 slices allocated*/
	uint16_t                               shadowtransfer_mask_w;  /*!< Shadow transfer mask as per CCU4 slices allocated*/
	uint8_t                                syncstart_enable;       /*!< This enables/disables synchronous start of ccu4 slices*/
}BC_CCU4_Config_t;

/**
  * This structure holds the BC parameters which change at run
  * time.
  */
typedef struct BC_CCU4
{
	const	BC_CCU4_SLICE_t*                     		const  	phase_ptr[6];         	/*!< Pointer to ccu4 phase timer init configuration structure*/
	const	BC_CCU4_SLICE_t*                     		const  	com_ptr;         		/*!< Pointer to ccu4 com timer init configuration structure*/
			GLOBAL_CCU4_t*							 	const	globalccu4_uv_ptr;		/*!< Pointer to the GLOBAL_CCU4 APP handle structure*/
			GLOBAL_CCU4_t*							 	const	globalccu4_w_ptr;		/*!< Pointer to the GLOBAL_CCU4 APP handle structure*/
			ZEROCROSSING_t*								const	zerocrossing_ptr;		/*!< Pointer to the ZEROCROSSING APP handle structure*/
	const  	XMC_CCU4_SLICE_EVENT_CONFIG_t*      		const  	startconfig_ptr;      	/*!< Pointer to start event configuration structure*/
	const  	XMC_CCU4_SLICE_COMPARE_CONFIG_t*    		const  	ph_timerinit_high_ptr;  /*!< CCU4 timer init structure pointer */
	const  	XMC_CCU4_SLICE_COMPARE_CONFIG_t*    		const  	ph_timerinit_low_ptr;   /*!< CCU4 timer init structure pointer */
	const	BC_CCU4_GPIO_t*								const	pwmoutpin_ptr[6];		/*!< GPIO pin initialization structure pointer for PWM pins*/
	const	XMC_GPIO_CONFIG_t*  		                const	pwmoutconfig_ptr[6];  	/*!< GPIO pin configuration structure pointer for PWM pins */
			BC_CCU4_STATE_t										state;					/*!< State of the APP */
	const  	BC_CCU4_Config_t*                    		const  	config_ptr;           	/*!< pointer to the Dynamic Handle of the APP */
	const   BC_CCU4_INTERRUPT_t*						const	int_com;				/*!< Pointer to commutation intterupt */
			uint16_t   			                                period;    		        /*!< This variable gives the period value*/
			uint16_t											compare;				/*!< This variable gives the compare value*/
			uint16_t											compare_start;
			uint8_t												pattern;
	        uint8_t                                    			dead_time;  /*!< Deadtime register value*/
	        uint16_t											speed_start_div;		/*!< Divider for start rampup speed*/
	        uint16_t											speed_end_div;			/*!< Divider for end rampup speed*/
	        uint16_t											com_div;				/*!< Divider for commutation*/
	        uint16_t											com_cnt;				/*!< counts commutation patterns*/
	        uint16_t											ramp_cnt;				/*!< ramp counter*/
}BC_CCU4_t;

/**
 * @}
 */

#ifdef __cplusplus
extern "C" {
#endif
/**
 * @ingroup BC_CCU4_apidoc
 * @{
 */
  /***********************************************************************************************************************
   * API Prototypes
   **********************************************************************************************************************/
DAVE_APP_VERSION_t BC_CCU4_GetAppVersion(void);
BC_CCU4_STATUS_t BC_CCU4_Init(BC_CCU4_t* HandlePtr);

void BC_CCU4_Start(BC_CCU4_t* HandlePtr);
void BC_CCU4_Stop(BC_CCU4_t* HandlePtr);
void BC_CCU4_SetMotorSpeedPercent(BC_CCU4_t* const HandlePtr, float speed);

void BC_CCU4_lSetNextCommutationPattern(BC_CCU4_t* const HandlePtr);
void BC_CCU4_lCommutationEventHandler(BC_CCU4_t* const HandlePtr);

/**
 * @}
 */

#include "bc_ccu4_extern.h"

#ifdef __cplusplus
}
#endif

#endif /* BC_CCU4_H_ */

