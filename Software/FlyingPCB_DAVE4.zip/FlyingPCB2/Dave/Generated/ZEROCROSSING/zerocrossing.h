/**
 * @file zerocorssing.h
 * @date 2016-07-22
*/

#ifndef ZEROCROSSING_H
#define ZEROCROSSING_H

/***********************************************************************************************************************
 * HEADER FILES
 **********************************************************************************************************************/

#include "GLOBAL_ADC/global_adc.h"
#include "zerocrossing_conf.h"

/***********************************************************************************************************************
 * MACROS
 **********************************************************************************************************************/
 
 #if (!((XMC_LIB_MAJOR_VERSION == 2U) && \
       (XMC_LIB_MINOR_VERSION >= 0U) && \
       (XMC_LIB_PATCH_VERSION >= 0U)))
#error "ZEROCROSSING requires XMC Peripheral Library v2.0.0 or higher"
#endif
/**
 * @}
 */
 /**********************************************************************************************************************
 * ENUMS
 **********************************************************************************************************************/
/**
 * @ingroup ZEROCROSSING_enumerations
 * @{
 */
/**@brief Return value of an API  */
typedef enum ZEROCROSSING_STATUS
{
	ZEROCROSSING_SUCCESS = 0, 		/**< APP is Initialized*/
	ZEROCROSSING_FAILURE, 		  	/**< Initialization failed*/
	ZEROCROSSING_UNINITIALIZED   	/**< APP is Uninitialized*/
} ZEROCROSSING_STATUS_t;
/**
 * @}
 */

/**********************************************************************************************************************
* DATA STRUCTURES
**********************************************************************************************************************/
/**
 * @ingroup ZEROCROSSING_datastructures
 * @{
 */

/**
 * @brief VADC channel configuration structure
 */
typedef struct ZEROCROSSING_CHANNEL
{
	uint8_t channel_no;
	XMC_VADC_CHANNEL_CONFIG_t* const channel_config;
	XMC_VADC_RESULT_CONFIG_t* const result_config;
} ZEROCROSSING_CHANNEL_t;

/**
 * @brief NVIC Configuration structure for scan request source interrupt.
 */
typedef struct ZEROCROSSING_ISRHandle_t
{
	uint32_t node_id;		 	/**< This indicates the NVIC Node number.*/
	uint32_t priority;	 		/**< This indicates the NVIC priority.*/
	uint32_t sub_priority; 		/**< This indicates the NVIC sub priority in XMC4x Devices.*/
	uint8_t irqctrl; 	     	/**< This indicates the service request source selected for the consumed NVIC node.*/
} ZEROCROSSING_ISR_t;

/**
 * @brief Configuration Data structure of ZEROCROSSING APP.
 */
typedef struct ZEROCROSSING_Handle
{
	const 	XMC_VADC_GROUP_CLASS_t 					iclass_config_handle;	/**< Holds the ICLASS Configurations*/
	const 	XMC_VADC_SCAN_CONFIG_t*			const 	scan_config_handle;		/**< Holds the LLD SCAN Structure*/
			GLOBAL_ADC_t* 					const 	global_handle;			/**< Holds the Global Pointer of the Group*/
			XMC_VADC_GROUP_t*				const 	group_handle;  		 	/**< Holds the group Pointer of the Group*/
			XMC_VADC_GATEMODE_t 					gating_mode;            /**< Gating mode configuration needed for Scan request source*/
	const 	ZEROCROSSING_ISR_t* 			const 	rs_intr_handle;			/**< Holds the ISR Handle*/
	const 	XMC_VADC_SR_t 							srv_req_node;			/**< Source event interrupt node pointer*/
			ZEROCROSSING_STATUS_t 					init_status;			/**< This holds the state of the ZEROCROSSING APP Instance*/
	const 	uint8_t 								instance_number;		/**< Holds the instance number*/
	const 	uint8_t 								iclass_num;			 	/**< Holds the ICLASS ID either ICLASS-0 or ICLASS-1*/
	const 	uint8_t 								group_index; 			/**< Represents group index number of scan instance*/
	const	ZEROCROSSING_CHANNEL_t*			const	channels[3];			/**< Holds pointer to channel structure*/
			uint16_t								phase_results[3];		/**< Holds result of channel conversion*/
			uint8_t									pattern;				/**< Commutation pattern, set by toplevel app*/
			uint8_t									crossing_detected;		/**< set when zerocrossing detected and reset when new pattern is applied*/
			uint16_t								reference_voltage;		/**< reference for zerocrossing detection */
			uint8_t									zerocrossing;			/**< zerocrossing signal*/
			uint8_t									disable_cnt;			/**< disable first adc samples because of freewheeling current*/
} ZEROCROSSING_t;

/**
 * @}
 */

#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************************************************************************
 * API Prototypes
 **********************************************************************************************************************/
/**
 * @ingroup ZEROCROSSING_apidoc
 * @{
 */

/**
 * @brief Get ZEROCROSSING APP version
 * @return DAVE_APP_VERSION_t APP version information (major, minor and patch number)
 *
 * \par<b>Description: </b><br>
 * The function can be used to check application software compatibility with a
 * specific version of the APP.
 *
 * Example Usage:
 *
 * @code
 * #include <DAVE.h>
 *
 * int main(void) {
 *   DAVE_STATUS_t init_status;
 *   DAVE_APP_VERSION_t version;
 *
 *   // Initialize ZEROCROSSING APP:
 *   // ZEROCROSSING_Init() is called from within DAVE_Init().
 *   init_status = DAVE_Init();
 *
 *   version = ZEROCROSSING_GetAppVersion();
 *   if (version.major != 1U) {
 *     // Probably, not the right version.
 *   }
 *
 *   // More code here
 *   while(1) {
 *
 *   }
 *   return (0);
 * }
 * @endcode
 */
DAVE_APP_VERSION_t ZEROCROSSING_GetAppVersion(void);

/**
 * @brief Initializes the ADC scan request source.
 * parameters. <BR>
 * @param handle_ptr pointer to the Instance variable<BR>
 * @return ZEROCROSSING_STATUS_t status of the initialization.
 *
 * \par<b>Description:</b><br>
 * Initializes the ADC scan request source.
 * Invokes various VADC LLD API to initialize the VADC scan request source. This would invoke
 * The GLBOAL_ADC_Init(), a specific instance would also invoke
 * CPU_CTRL_XMCx_Init (x = 4 or 1). It also invokes XMC_VADC_GROUP_ScanInit() XMC_VADC_GROUP_ScanSetGatingMode()
 * XMC_VADC_GROUP_ScanSetReqSrcEventInterruptNode() to configure the scan source.
 *
 * @code
 * #include <DAVE.h>
 * int main(void)
 * {
 *    DAVE_Init(); //ZEROCROSSING_Init is called within DAVE_Init
 *    while(1);
 *    return 0;
 * }
 @endcode
 */
ZEROCROSSING_STATUS_t ZEROCROSSING_Init(ZEROCROSSING_t *const handle_ptr);

/**
 * @brief  Starts the scan request source arbitration.<BR>
 * @param handle_ptr pointer (ZEROCROSSING_t) to the instance variable and the handle pointer.<BR>
 * @return None <BR>
 *
 * \par<b>Description:</b><br>
 * Starts the VADC arbiter for the scan request source.<BR>
 * After this API is invoked the ADC is ready for accepting conversion requests. When invoked this API
 * would write to GxARBPR.ASEN1 bit to enable the arbiter.
 *
 * @code
  #include <DAVE.h>

  int main(void)
  {

     DAVE_Init(); //ZEROCROSSING_Init is called within DAVE_Init

     ZEROCROSSING_EnableArbitration(&ZEROCROSSING_0);
     while(1);
     return 0;
  }
 @endcode
 */
__STATIC_INLINE void ZEROCROSSING_EnableArbitration(ZEROCROSSING_t *const handle_ptr)
{
  XMC_ASSERT("ZEROCROSSING_EnableArbitration:Invalid handle_ptr", (handle_ptr != NULL))

  XMC_VADC_GROUP_ScanEnableArbitrationSlot(handle_ptr->group_handle);
}

/**
 * @brief  Stops the scan request source arbitration.<BR>
 * @param handle_ptr pointer (ZEROCROSSING_t) to the instance variable and the handle pointer.<BR>
 * @return None <BR>
 *
 * \par<b>Description:</b><br>
 * Stops the VADC arbiter for the scan request source.<BR>
 * After this API is invoked the ADC is ready for accepting conversion requests. When invoked this API
 * would write to GxARBPR.ASEN1 bit to disable the arbiter.
 *
 * @code
 * //Enable the Request source interrupt in the UI editor of the APP.
  #include <DAVE.h>

  int main(void)
  {

     DAVE_Init(); //ZEROCROSSING_Init is called within DAVE_Init
     ZEROCROSSING_DisableArbitration(&ZEROCROSSING_0);

     //put your code here

     ZEROCROSSING_EnableArbitration(&ZEROCROSSING_0);
     while(1);
     return 0;
  }
 @endcode
 */
__STATIC_INLINE void ZEROCROSSING_DisableArbitration(ZEROCROSSING_t *const handle_ptr)
{
  XMC_ASSERT("ZEROCROSSING_DisableArbitration:Invalid handle_ptr", (handle_ptr != NULL))

  XMC_VADC_GROUP_ScanDisableArbitrationSlot(handle_ptr->group_handle);
}

/**
 * @brief Scan Request source interrupt handler.<BR>
 * @param handle_ptr pointer (ZEROCROSSING_t) to the instance variable <BR>
 * @return None <BR>
 *
 * \par<b>Description:</b><br>
 * Scan Request source interrupt handler.
 */
void ZEROCROSSING_ReqSrcEventHandler(ZEROCROSSING_t *const handle_ptr);

/**
 * @}
 */
#include "ZEROCROSSING_Extern.h"
#ifdef __cplusplus
}
#endif
 
#endif /* ZEROCROSSING_H */
