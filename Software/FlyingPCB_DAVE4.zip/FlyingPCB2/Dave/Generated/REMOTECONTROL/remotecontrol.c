#include "remotecontrol.h"

int32_t map(int32_t x, int32_t in_min, int32_t in_max, int32_t out_min, int32_t out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

REMOTECONTROL_STATUS_t REMOTECONTROL_Init(REMOTECONTROL_t *const handle)
{
	uint32_t fifo_size;
	uint32_t ret_limit_val=0U;

	REMOTECONTROL_STATUS_t status = REMOTECONTROL_STATUS_SUCCESS;

	handle->rx_buffer = (uint8_t*)malloc((handle->config->frame_size)*sizeof(uint8_t));

	XMC_GPIO_Init(handle->rx_pin_ptr->port, handle->rx_pin_ptr->pin, handle->rx_pin_ptr->config);
	XMC_GPIO_Init(handle->tx_pin_ptr->port, handle->tx_pin_ptr->pin, handle->tx_pin_ptr->config);

	XMC_UART_CH_Init(handle->channel, handle->channel_config);

	XMC_USIC_CH_SetInputSource(handle->channel, XMC_USIC_CH_INPUT_DX0, handle->config->source_dx0);

	XMC_USIC_CH_TXFIFO_Configure(handle->channel, handle->config->tb_data_pointer, handle->config->tx_fifo_size, handle->config->tx_limit);
	XMC_USIC_CH_RXFIFO_Configure(handle->channel, handle->config->rb_data_pointer, handle->config->rx_fifo_size, handle->config->rx_limit);

	XMC_UART_CH_Start(handle->channel);

	if (handle->config->rx_fifo_size != XMC_USIC_CH_FIFO_DISABLED)
	{
		XMC_USIC_CH_RXFIFO_SetInterruptNodePointer(handle->channel, XMC_USIC_CH_RXFIFO_INTERRUPT_NODE_POINTER_STANDARD, handle->rx_int_ptr->nodepointer);
		XMC_USIC_CH_RXFIFO_EnableEvent(handle->channel, XMC_USIC_CH_RXFIFO_EVENT_CONF_STANDARD);

		fifo_size = (uint32_t)(0x01UL << (uint8_t)(handle->config->rx_fifo_size));
		if (handle->config->frame_size < fifo_size)
			ret_limit_val = (uint32_t)(handle->config->frame_size - 1U);
		else
			ret_limit_val = (uint32_t)(fifo_size - 1U);

		/*Set the limit value*/
		XMC_USIC_CH_RXFIFO_SetSizeTriggerLimit(handle->channel,	handle->config->rx_fifo_size, ret_limit_val);
	}
	else
	{
		XMC_USIC_CH_SetInterruptNodePointer(handle->channel, XMC_USIC_CH_INTERRUPT_NODE_POINTER_RECEIVE, handle->rx_int_ptr->nodepointer);
		XMC_USIC_CH_EnableEvent(handle->channel, XMC_USIC_CH_EVENT_STANDARD_RECEIVE);
	}

	NVIC_SetPriority(handle->rx_int_ptr->node, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), handle->rx_int_ptr->priority, handle->rx_int_ptr->subpriority));
	NVIC_EnableIRQ(handle->rx_int_ptr->node);

	//Watchdog configuration
	status |= GLOBAL_CCU4_Init(handle->globalccu4_ptr);
	XMC_CCU4_SLICE_CompareInit(handle->watchdog_ptr->slice_ptr, handle->watchdog_timerinit_ptr);
	XMC_CCU4_SLICE_SetTimerPeriodMatch(handle->watchdog_ptr->slice_ptr, handle->config->period);
	XMC_CCU4_EnableShadowTransfer(handle->watchdog_ptr->module_ptr, handle->watchdog_ptr->shadowtransfer_mask);

	XMC_CCU4_SLICE_SetInterruptNode(handle->watchdog_ptr->slice_ptr,
									XMC_CCU4_SLICE_IRQ_ID_PERIOD_MATCH,
									(XMC_CCU4_SLICE_SR_ID_t)handle->config->event_sr_selector);
	XMC_CCU4_SLICE_EnableEvent(handle->watchdog_ptr->slice_ptr, XMC_CCU4_SLICE_IRQ_ID_PERIOD_MATCH);

	NVIC_SetPriority(handle->watchdog_int_ptr->node, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), handle->watchdog_int_ptr->priority, handle->watchdog_int_ptr->subpriority));
	NVIC_EnableIRQ(handle->watchdog_int_ptr->node);

	XMC_CCU4_EnableClock(handle->watchdog_ptr->module_ptr, handle->watchdog_ptr->slice_number);
	XMC_CCU4_SLICE_StartTimer(handle->watchdog_ptr->slice_ptr);

	return status;
}

void REMOTECONTROL_lReceiveHandler(REMOTECONTROL_t *const handle)
{
	int32_t checksum=0;
	int32_t checksum_rec=0;

	//Raw values from receiver
	uint8_t start = 0;

	for (uint8_t i=0; i<handle->config->frame_size; i++)
		handle->rx_buffer[i] = (uint8_t)XMC_UART_CH_GetReceivedData(handle->channel);

	if (handle->type == REMOTECONTROL_TYPE_BLUETOOTH)
	{
		if (handle->rx_buffer[0] == 0)
		{
			checksum = handle->rx_buffer[0];
			checksum ^= ((handle->rx_buffer[1] << 8 | handle->rx_buffer[2]) & 0xFFFF);
			for (uint8_t i=3; i<(handle->config->frame_size-4)-1; i+=4)
				checksum ^= (handle->rx_buffer[i] << 24 | handle->rx_buffer[i+1] << 16 | handle->rx_buffer[i+2] << 8 | handle->rx_buffer[i+3]);

			for (uint8_t i=0; i<4; i++)
				*((uint8_t*)(&checksum_rec) + 3-i) = handle->rx_buffer[15+i];

			if (checksum == checksum_rec)
			{
				handle->data.throttle = handle->rx_buffer[2];
				for (uint8_t i=0; i<4; i++)
				{
					*((uint8_t*)(&handle->data.rudder) + 3-i) = handle->rx_buffer[3+i];
					*((uint8_t*)(&handle->data.aileron) + 3-i) = handle->rx_buffer[7+i];
					*((uint8_t*)(&handle->data.elevator) + 3-i) = handle->rx_buffer[11+i];
				}

				handle->new_data=1;
			}
			else
			{
				handle->data.throttle = 0;
				handle->data.rudder = 0;
				handle->data.elevator = 0;
				handle->data.aileron = 0;
			}
		}

		//Send Keep-Alive
		uint8_t trans=0x00;
		REMOTECONTROL_Transmit(handle, &trans, 1);

		// USED for MCI Android App
		/*while(((uint8_t)XMC_UART_CH_GetReceivedData(handle->channel)) != START_BYTE);

		for (uint8_t i=0; i<handle->config->frame_size; i++)
		{
			handle->rx_buffer[i] = (uint8_t)XMC_UART_CH_GetReceivedData(handle->channel);
			if (i < handle->config->frame_size-3)
				checksum+=(uint16_t)(255-handle->rx_buffer[i]);
		}

		checksum+=1;
		checksum_send = (handle->rx_buffer[handle->config->frame_size-2] << 8) | handle->rx_buffer[handle->config->frame_size-3];

		if (checksum == checksum_send)
		{
			handle->data.throttle = (handle->rx_buffer[1] << 8) | handle->rx_buffer[0];
			handle->data.rudder = (handle->rx_buffer[3] << 8) | handle->rx_buffer[2];
			handle->data.elevator = (handle->rx_buffer[5] << 8) | handle->rx_buffer[4];
			handle->data.aileron = (handle->rx_buffer[7] << 8) | handle->rx_buffer[6];
		}*/
	}
	else if (handle->type == REMOTECONTROL_TYPE_SATELLITE)
	{
		//Search for start byte and check static values
		while (handle->rx_buffer[start] != 0x30 || handle->rx_buffer[start+1] != 0x00 || handle->rx_buffer[start+5] != 0xA2 || handle->rx_buffer[start+8] != 0x2B || handle->rx_buffer[start+9] != 0xFE)
		{
			if (start++ > 16) {
				//Communication check bytes not in buffer
				return;
			}
		}
		handle->data_raw.throttle = (handle->rx_buffer[start+2] << 8) | handle->rx_buffer[start+3];
		handle->data.throttle = map(handle->data_raw.throttle, THROTTLE_MIN, THROTTLE_MAX, 0, 32767);
		handle->data_raw.aileron = (handle->rx_buffer[start+6] << 8) | handle->rx_buffer[start+7];
		handle->data.aileron = map(handle->data_raw.aileron, AILERON_MIN, AILERON_MAX, -32768, 32767);
		handle->data_raw.elevator = (handle->rx_buffer[start+10] << 8) | handle->rx_buffer[start+11];
		handle->data.elevator = map(handle->data_raw.elevator, ELEVATOR_MIN, ELEVATOR_MAX, -32768, 32767);
		handle->data_raw.rudder = (handle->rx_buffer[start+14] << 8) | handle->rx_buffer[start+15];
		handle->data.rudder = map(handle->data_raw.rudder, RUDDER_MIN, RUDDER_MAX, -32768, 32767);
		handle->data_raw.flightmode = (handle->rx_buffer[start+12] << 8) | handle->rx_buffer[start+13];
		if (handle->data_raw.flightmode == FLIGHTMODE0) handle->data.flightmode = 0;
		if (handle->data_raw.flightmode == FLIGHTMODE1) handle->data.flightmode = 1;

		handle->new_data=1;
	}

	handle->timeout=false;
	XMC_CCU4_SLICE_ClearTimer(handle->watchdog_ptr->slice_ptr);

	XMC_USIC_CH_RXFIFO_Flush(handle->channel);
}

REMOTECONTROL_STATUS_t REMOTECONTROL_Transmit(REMOTECONTROL_t *const handle, uint8_t* data_ptr, uint32_t count)
{
	REMOTECONTROL_STATUS_t ret_stat = REMOTECONTROL_STATUS_BUFFER_INVALID;
	uint32_t loc_index;

	if ((data_ptr != NULL) && (count > 0U))
	{
		ret_stat = REMOTECONTROL_STATUS_BUSY;
		if (handle->tx_busy == false)
		{
			handle->tx_busy = true;
			if (handle->config->tx_fifo_size != XMC_USIC_CH_FIFO_DISABLED)
			{
				/*Clear the transmit FIFO*/
				XMC_USIC_CH_TXFIFO_Flush(handle->channel);
			}
			/*Loop through each byte*/
			for (loc_index = 0U; loc_index < count; loc_index++)
			{
				/*If FIFO is enabled, FIFO filling status should be checked
				 * to avoid overflow error*/
				if (handle->config->tx_fifo_size != XMC_USIC_CH_FIFO_DISABLED)
				{
					/*Wait if transmit FIFO is full*/
					while (XMC_USIC_CH_TXFIFO_IsFull(handle->channel) == true)
					{
					}
				}
				XMC_UART_CH_Transmit(handle->channel, (uint16_t)data_ptr[loc_index]);
			}

			if (handle->config->tx_fifo_size != XMC_USIC_CH_FIFO_DISABLED)
			{
				/*Wait till FIFO is empty*/
				while (XMC_USIC_CH_TXFIFO_IsEmpty(handle->channel) == false)
				{
				}
			}
			ret_stat = REMOTECONTROL_STATUS_SUCCESS;
			handle->tx_busy = false;
		}
	}
	return ret_stat;
}

REMOTECONTROL_STATUS_t REMOTECONTROL_GetRCData(REMOTECONTROL_t *const handle, float* data)
{
	REMOTECONTROL_STATUS_t status = REMOTECONTROL_STATUS_SUCCESS;

	if (handle->timeout)
		status = REMOTECONTROL_STATUS_TIMEOUT;

	if (handle->data.flightmode)
		status = REMOTECONTROL_STATUS_FLIGHTMODE;

	data[0]=handle->data.throttle;
	data[1]=handle->data.aileron;
	data[2]=handle->data.elevator;
	data[3]=handle->data.rudder;

	return status;
}

void REMOTECONTROL_lWatchdogHandler(REMOTECONTROL_t *const handle)
{
	handle->timeout=true;
}
