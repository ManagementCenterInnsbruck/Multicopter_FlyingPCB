#include "mpu9x50.h"

volatile unsigned long timingdelay;

void delay (unsigned long time);

MPU9X50_STATUS_t MPU9X50_Init(MPU9X50_t *const handle)
{
	MPU9X50_STATUS_t status;

	if (handle != NULL)
	{
		/* Init systimer */
		SysTick_Config(SYSTIMER_SYSTICK_CLOCK * SYSTIMER_TICK_PERIOD);
		NVIC_SetPriority(SysTick_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), SYSTIMER_PRIORITY, SYSTIMER_SUBPRIORITY));

		delay(3000);

		XMC_I2C_CH_Init(handle->channel, handle->config->brg_config);

		XMC_USIC_CH_SetInputSource(handle->channel, XMC_USIC_CH_INPUT_DX0, handle->config->source_dx0);
		XMC_USIC_CH_SetInputSource(handle->channel, XMC_USIC_CH_INPUT_DX1, handle->config->source_dx1);

		XMC_USIC_CH_TXFIFO_Configure(handle->channel, handle->config->tb_data_pointer, handle->config->txFIFO_size, handle->config->tx_limit);
		XMC_USIC_CH_RXFIFO_Configure(handle->channel, handle->config->rb_data_pointer, handle->config->rxFIFO_size, handle->config->rx_limit);

		XMC_I2C_CH_Start(handle->channel);

		XMC_GPIO_Init(handle->sda_outpin_ptr->port, handle->sda_outpin_ptr->pin, handle->sda_outconfig_ptr);
		XMC_GPIO_Init(handle->scl_outpin_ptr->port, handle->scl_outpin_ptr->pin, handle->scl_outconfig_ptr);

		MPU9X50_Setup(handle);

		/*Configure external interrupt*/
		XMC_GPIO_Init(handle->int_outpin_ptr->port, handle->int_outpin_ptr->pin, handle->int_outconfig_ptr);
		XMC_ERU_ETL_Init(handle->eru, handle->etl, handle->etl_config);
		XMC_ERU_OGU_SetServiceRequestMode(handle->eru, handle->ogu, XMC_ERU_OGU_SERVICE_REQUEST_ON_TRIGGER);
		NVIC_SetPriority(handle->ext_int->node, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), handle->ext_int->priority, handle->ext_int->subpriority));
		NVIC_EnableIRQ(handle->ext_int->node);

		status = MPU9X50_STATUS_SUCCESS;
	}
	else
		status = MPU9X50_STATUS_FAILURE;

	return (status);
}

MPU9X50_STATUS_t MPU9X50_lStartTransmitPolling(MPU9X50_t *const handle, bool send_start, const uint32_t slave_address, uint8_t *data,uint32_t size, bool send_stop)
{
	uint32_t buffer_index;
	MPU9X50_STATUS_t status;

	status = MPU9X50_STATUS_BUSY;

	buffer_index = 0U;

	if ((((send_start == false) && (handle->runtime->bus_acquired == false)) || (data == NULL) || (size == 0U)))
	{
		status = MPU9X50_STATUS_FAILURE;
	}
	else
	{
		if (send_start == true)
		{
			if (handle->runtime->bus_acquired == false)
			{
				handle->runtime->bus_acquired = true;
				XMC_I2C_CH_MasterStart(handle->channel, slave_address, XMC_I2C_CH_CMD_WRITE);
				while ((XMC_I2C_CH_GetStatusFlag(handle->channel) & XMC_I2C_CH_STATUS_FLAG_ACK_RECEIVED) == 0U)
				{
					/* wait for ACK */
				}
				XMC_I2C_CH_ClearStatusFlag(handle->channel, (uint32_t)XMC_I2C_CH_STATUS_FLAG_ACK_RECEIVED);
			}
		}

		if (handle->config->txFIFO_size == XMC_USIC_CH_FIFO_DISABLED)
		{
			/* send data, byte by byte */
			while (buffer_index < size)
			{
				XMC_I2C_CH_MasterTransmit(handle->channel, data[buffer_index]);
				while ((XMC_I2C_CH_GetStatusFlag(handle->channel) & XMC_I2C_CH_STATUS_FLAG_ACK_RECEIVED) == 0U)
				{
					/* wait for ACK */
				}
				XMC_I2C_CH_ClearStatusFlag(handle->channel, (uint32_t)XMC_I2C_CH_STATUS_FLAG_ACK_RECEIVED);

				buffer_index++;
			}
		}
		else
		{
			while (buffer_index < size)
			{
				/* Fill the transmit FIFO */
				while (XMC_USIC_CH_TXFIFO_IsFull(handle->channel) == false)
				{
					/* transmit each byte till index reaches to the last byte */
					if (buffer_index < size)
					{
						/* load the FIFO, byte by byte till either FIFO is full or all data is loaded*/
						XMC_I2C_CH_MasterTransmit(handle->channel, data[buffer_index]);
						buffer_index++;
					}
					else
					{
						break;
					}
				}
			}
			/*make sure data is transmitted from FIFO*/
			while (!XMC_USIC_CH_TXFIFO_IsEmpty(handle->channel)){}
		}

		if(send_stop == true)
		{
			handle->runtime->bus_acquired = false;
			XMC_I2C_CH_MasterStop(handle->channel);
		}

		status = MPU9X50_STATUS_SUCCESS;
	}

	return (status);
}

MPU9X50_STATUS_t MPU9X50_lStartReceivePolling(MPU9X50_t *const handle, bool send_start, uint32_t slave_address, uint8_t *data, uint32_t count, bool send_stop, bool send_nack)
{
	MPU9X50_STATUS_t status;
	uint32_t buffer_index;
	uint32_t temp_index;

	status = MPU9X50_STATUS_BUSY;
	if ((((send_start == false) && (handle->runtime->bus_acquired == false)) || (data == NULL) || (count == 0U)))
	{
		status = MPU9X50_STATUS_FAILURE;
	}
	else
	{
		buffer_index = 0U;
		temp_index = 0U;
		if (send_start == true)
		{
			if (handle->runtime->bus_acquired == true)
			{
				XMC_I2C_CH_MasterRepeatedStart(handle->channel, (uint16_t)slave_address, XMC_I2C_CH_CMD_READ);
			}
			else
			{
			    handle->runtime->bus_acquired = true;
			    XMC_I2C_CH_MasterStart(handle->channel, (uint16_t)slave_address, XMC_I2C_CH_CMD_READ);
			}
			while ((XMC_I2C_CH_GetStatusFlag(handle->channel) & XMC_I2C_CH_STATUS_FLAG_ACK_RECEIVED) == 0U)
			{
				/* wait for ACK */
			}
			XMC_I2C_CH_ClearStatusFlag(handle->channel, (uint32_t)XMC_I2C_CH_STATUS_FLAG_ACK_RECEIVED);
		}

		if (handle->config->txFIFO_size == XMC_USIC_CH_FIFO_DISABLED)
		{
			while (buffer_index < count)
			{
				if (((buffer_index + 1U) == count) && (send_nack == true))
				{
					XMC_I2C_CH_MasterReceiveNack(handle->channel);
				}
				else
				{
					XMC_I2C_CH_MasterReceiveAck(handle->channel);
				}

				while(((XMC_I2C_CH_GetStatusFlag(handle->channel) & XMC_I2C_CH_STATUS_FLAG_ALTERNATIVE_RECEIVE_INDICATION) == 0U) &&
					  ((XMC_I2C_CH_GetStatusFlag(handle->channel) & XMC_I2C_CH_STATUS_FLAG_RECEIVE_INDICATION) == 0U))
				{
					/* wait for RSI */
				}

				XMC_I2C_CH_ClearStatusFlag(handle->channel, (uint32_t)XMC_I2C_CH_STATUS_FLAG_ALTERNATIVE_RECEIVE_INDICATION);
				XMC_I2C_CH_ClearStatusFlag(handle->channel, (uint32_t)XMC_I2C_CH_STATUS_FLAG_RECEIVE_INDICATION);

				data[buffer_index++] = XMC_I2C_CH_GetReceivedData(handle->channel);
			}
		} /* end of if (handle->config->txFIFO_size == XMC_USIC_CH_FIFO_DISABLED) */
		else
		{
			temp_index = buffer_index;
			while (temp_index < count)
			{
				while (XMC_USIC_CH_TXFIFO_IsFull(handle->channel) == false)
				{
					/* transmit each byte till index reaches to the last byte */
					if (temp_index < count)
					{
						/* load the FIFO, byte by byte till either FIFO is full or all data is loaded*/
						if (((temp_index + 1U) == count) && (send_nack == true))
						{
							XMC_I2C_CH_MasterReceiveNack(handle->channel);
						}
						else
						{
							XMC_I2C_CH_MasterReceiveAck(handle->channel);
						}
						temp_index++;
					}
					else
					{
						break;
					}
				} /* end of while (MPU9X50_IsTXFIFOFull(handle) == false) */

				while (buffer_index < temp_index)
				{
					/* wait for data to come in RX fifo */
					while (XMC_USIC_CH_RXFIFO_IsEmpty(handle->channel)){}
					data[buffer_index++] = XMC_I2C_CH_GetReceivedData(handle->channel);
				}
			} /* end of while (temp_index < count) */
		} /* end of else */

		if (send_stop == true)
		{
			handle->runtime->bus_acquired = false;
			XMC_I2C_CH_MasterStop(handle->channel);
		}
	}

	return (status);
}

void MPU9X50_Transmit(MPU9X50_t *const handle, uint8_t reg_address, uint8_t *data, uint32_t size)
{
	MPU9X50_lStartTransmitPolling(handle, true, handle->slave_address, &reg_address, 1, false);
	MPU9X50_lStartTransmitPolling(handle, false, handle->slave_address, data, size, true);
}

void MPU9X50_TransmitByte(MPU9X50_t *const handle, uint8_t reg_address, uint8_t data)
{
	MPU9X50_Transmit(handle, reg_address, &data, 1);
}

void MPU9X50_Receive(MPU9X50_t *const handle, uint8_t reg_address, uint8_t *data, uint32_t size)
{
	MPU9X50_lStartTransmitPolling(handle, true, handle->slave_address, &reg_address, 1, true);
	MPU9X50_lStartReceivePolling(handle, true, handle->slave_address, data, size, true, true);
}

uint8_t MPU9X50_ReceiveByte(MPU9X50_t *const handle, uint8_t reg_address)
{
	uint8_t rec;
	MPU9X50_Receive(handle, reg_address, &rec, 1);
	return rec;
}

void MPU9X50_Setup(MPU9X50_t *const handle)
{
	// Read the WHO_AM_I register, this is a good test of communication
	uint8_t rec=MPU9X50_ReceiveByte(handle, WHO_AM_I);

	if (rec == 0x68 || rec == 0x71 || rec == 0x73) // WHO_AM_I should always be 0x68 (MPU9150 or MPU9250)
	{
		if (MPU9X50_SelfTest(handle) == MPU9X50_STATUS_SUCCESS)
		{
			//MPU9X50_Calibrate(handle); 	// Calibrate gyro and accelerometers, load biases in bias registers
			MPU9X50_InitSlave(handle); 		// Inititalize and configure accelerometer and gyroscope
		}
	}
}

// Accelerometer and gyroscope self test; check calibration wrt factory settings
// Should return percent deviation from factory trim values, +/- 14 or less deviation is a pass
MPU9X50_STATUS_t MPU9X50_SelfTest(MPU9X50_t *const handle)
{
	uint8_t rawData[4];
	uint8_t selfTest[6];
	float factoryTrim[6];
	float result[6];

	// Configure the accelerometer for self-test
	MPU9X50_TransmitByte(handle, ACCEL_CONFIG, 0xF0);  // Enable self test on all three axes and set accelerometer range to +/- 8 g
	MPU9X50_TransmitByte(handle, GYRO_CONFIG, 0xE0);   // Enable self test on all three axes and set gyro range to +/- 250 degrees/s

	delay(250);  // Delay a while to let the device execute the self-test

	rawData[0] = MPU9X50_ReceiveByte(handle, SELF_TEST_X); // X-axis self-test results
	rawData[1] = MPU9X50_ReceiveByte(handle, SELF_TEST_Y); // Y-axis self-test results
	rawData[2] = MPU9X50_ReceiveByte(handle, SELF_TEST_Z); // Z-axis self-test results
	rawData[3] = MPU9X50_ReceiveByte(handle, SELF_TEST_A); // Mixed-axis self-test results
	// Extract the acceleration test results first
	selfTest[0] = (rawData[0] >> 3) | (rawData[3] & 0x30) >> 4 ; // XA_TEST result is a five-bit unsigned integer
	selfTest[1] = (rawData[1] >> 3) | (rawData[3] & 0x0C) >> 4 ; // YA_TEST result is a five-bit unsigned integer
	selfTest[2] = (rawData[2] >> 3) | (rawData[3] & 0x03) >> 4 ; // ZA_TEST result is a five-bit unsigned integer
	// Extract the gyration test results first
	selfTest[3] = rawData[0]  & 0x1F ; // XG_TEST result is a five-bit unsigned integer
	selfTest[4] = rawData[1]  & 0x1F ; // YG_TEST result is a five-bit unsigned integer
	selfTest[5] = rawData[2]  & 0x1F ; // ZG_TEST result is a five-bit unsigned integer
	// Process results to allow final comparison with factory set values
	factoryTrim[0] = (4096.0*0.34)*(pow( (0.92/0.34) , (((float)selfTest[0] - 1.0)/30.0))); // FT[Xa] factory trim calculation
	factoryTrim[1] = (4096.0*0.34)*(pow( (0.92/0.34) , (((float)selfTest[1] - 1.0)/30.0))); // FT[Ya] factory trim calculation
	factoryTrim[2] = (4096.0*0.34)*(pow( (0.92/0.34) , (((float)selfTest[2] - 1.0)/30.0))); // FT[Za] factory trim calculation
	factoryTrim[3] =  ( 25.0*131.0)*(pow( 1.046 , ((float)selfTest[3] - 1.0) ));             // FT[Xg] factory trim calculation
	factoryTrim[4] =  (-25.0*131.0)*(pow( 1.046 , ((float)selfTest[4] - 1.0) ));             // FT[Yg] factory trim calculation
	factoryTrim[5] =  ( 25.0*131.0)*(pow( 1.046 , ((float)selfTest[5] - 1.0) ));             // FT[Zg] factory trim calculation

	// Report results as a ratio of (STR - FT)/FT; the change from Factory Trim of the Self-Test Response
	// To get to percent, must multiply by 100 and subtract result from 100
	for (int i = 0; i < 6; i++)
		result[i] = 100.0 + 100.0*((float)selfTest[i] - factoryTrim[i])/factoryTrim[i]; // Report percent differences

	if(result[0] < 1.0f && result[1] < 1.0f && result[2] < 1.0f && result[3] < 1.0f && result[4] < 1.0f && result[5] < 1.0f)
		return MPU9X50_STATUS_SUCCESS;
	else
		return MPU9X50_STATUS_FAILURE;
}

// Function which accumulates gyro and accelerometer data after device initialization. It calculates the average
// of the at-rest readings and then loads the resulting offsets into accelerometer and gyro bias registers.
void MPU9X50_Calibrate(MPU9X50_t *const handle)
{
	uint8_t data[6]; // data array to hold accelerometer and gyro x, y, z, data
	uint16_t ii, packet_count;
	int32_t gyro_bias[3]  = {0, 0, 0}, accel_bias[3] = {0, 0, 0};

	// reset device, reset all registers, clear gyro and accelerometer bias registers
	MPU9X50_TransmitByte(handle, PWR_MGMT_1, 0x80); // Write a one to bit 7 reset bit; toggle reset device
	delay(100);

	// get stable time source
	// Set clock source to be PLL with x-axis gyroscope reference, bits 2:0 = 001
	MPU9X50_TransmitByte(handle, PWR_MGMT_1, 0x01);
	MPU9X50_TransmitByte(handle, PWR_MGMT_2, 0x00);
	delay(200);

	// Configure device for bias calculation
	MPU9X50_TransmitByte(handle, INT_ENABLE, 0x00);   // Disable all interrupts
	MPU9X50_TransmitByte(handle, FIFO_EN, 0x00);      // Disable FIFO
	MPU9X50_TransmitByte(handle, PWR_MGMT_1, 0x00);   // Turn on internal clock source
	MPU9X50_TransmitByte(handle, I2C_MST_CTRL, 0x00); // Disable I2C master
	MPU9X50_TransmitByte(handle, USER_CTRL, 0x00);    // Disable FIFO and I2C master modes
	MPU9X50_TransmitByte(handle, USER_CTRL, 0x0C);    // Reset FIFO and DMP
	delay(100);

	// Configure MPU6050 gyro and accelerometer for bias calculation
	MPU9X50_TransmitByte(handle, CONFIG, 0x01);      // Set low-pass filter to 188 Hz
	MPU9X50_TransmitByte(handle, SMPLRT_DIV, 0x00);  // Set sample rate to 1 kHz
	MPU9X50_TransmitByte(handle, GYRO_CONFIG, 0x00);  // Set gyro full-scale to 250 degrees per second, maximum sensitivity
	MPU9X50_TransmitByte(handle, ACCEL_CONFIG, 0x00); // Set accelerometer full-scale to 2 g, maximum sensitivity

	uint16_t accelsensitivity = 16384;  // = 16384 LSB/g

	/*// Configure FIFO to capture accelerometer and gyro data for bias calculation
	MPU9X50_TransmitByte(handle, USER_CTRL, 0x40);   // Enable FIFO
	MPU9X50_TransmitByte(handle, FIFO_EN, 0x78);     // Enable gyro and accelerometer sensors for FIFO  (max size 1024 bytes in MPU-6050)
	delay(500); // accumulate 80 samples in 80 milliseconds = 960 bytes

	// At end of sample accumulation, turn off FIFO sensor read
	MPU9X50_TransmitByte(handle, FIFO_EN, 0x00);        // Disable gyro and accelerometer sensors for FIFO
	MPU9X50_Receive(handle, FIFO_COUNTH, data, 2); // read FIFO sample count
	fifo_count = ((uint16_t)data[0] << 8) | data[1];
	packet_count = fifo_count/12;// How many sets of full gyro and accelerometer data for averaging

	for (ii = 0; ii < packet_count; ii++)
	{
		int16_t accel_temp[3] = {0, 0, 0}, gyro_temp[3] = {0, 0, 0};
		MPU9X50_Receive(handle, FIFO_R_W, data, 12); // read data for averaging
		accel_temp[0] = (int16_t) (((int16_t)data[0] << 8) | data[1]  ) ;  // Form signed 16-bit integer for each sample in FIFO
		accel_temp[1] = (int16_t) (((int16_t)data[2] << 8) | data[3]  ) ;
		accel_temp[2] = (int16_t) (((int16_t)data[4] << 8) | data[5]  ) ;
		gyro_temp[0]  = (int16_t) (((int16_t)data[6] << 8) | data[7]  ) ;
		gyro_temp[1]  = (int16_t) (((int16_t)data[8] << 8) | data[9]  ) ;
		gyro_temp[2]  = (int16_t) (((int16_t)data[10] << 8) | data[11]) ;

		accel_bias[0] += (int32_t) accel_temp[0]; // Sum individual signed 16-bit biases to get accumulated signed 32-bit biases
		accel_bias[1] += (int32_t) accel_temp[1];
		accel_bias[2] += (int32_t) accel_temp[2];
		gyro_bias[0]  += (int32_t) gyro_temp[0];
		gyro_bias[1]  += (int32_t) gyro_temp[1];
		gyro_bias[2]  += (int32_t) gyro_temp[2];
	}*/

	packet_count=200;

	for (ii=0; ii < packet_count; ii++)
	{
		int16_t accel_temp[3] = {0, 0, 0};
		MPU9X50_Receive(handle, ACCEL_XOUT_H, data, 6);
		accel_temp[0] = (int16_t) (((int16_t)data[0] << 8) | data[1]  ) ;  // Form signed 16-bit integer for each sample in FIFO
		accel_temp[1] = (int16_t) (((int16_t)data[2] << 8) | data[3]  ) ;
		accel_temp[2] = (int16_t) (((int16_t)data[4] << 8) | data[5]  ) ;

		accel_bias[0] += (int32_t) accel_temp[0]; // Sum individual signed 16-bit biases to get accumulated signed 32-bit biases
		accel_bias[1] += (int32_t) accel_temp[1];
		accel_bias[2] += (int32_t) accel_temp[2];

		delay(10);
	}

	accel_bias[0] /= (int32_t) packet_count; // Normalize sums to get average count biases
    accel_bias[1] /= (int32_t) packet_count;
    accel_bias[2] /= (int32_t) packet_count;
    gyro_bias[0]  /= (int32_t) packet_count;
    gyro_bias[1]  /= (int32_t) packet_count;
    gyro_bias[2]  /= (int32_t) packet_count;

    if(accel_bias[2] < 0L)
    	accel_bias[2] -= (int32_t) accelsensitivity;  // Remove gravity from the z-axis accelerometer bias calculation
    else
    	accel_bias[2] += (int32_t) accelsensitivity;

    // Construct the gyro biases for push to the hardware gyro bias registers, which are reset to zero upon device startup
    data[0] = (-gyro_bias[0]/4  >> 8) & 0xFF; // Divide by 4 to get 32.9 LSB per deg/s to conform to expected bias input format
    data[1] = (-gyro_bias[0]/4)       & 0xFF; // Biases are additive, so change sign on calculated average gyro biases
    data[2] = (-gyro_bias[1]/4  >> 8) & 0xFF;
    data[3] = (-gyro_bias[1]/4)       & 0xFF;
    data[4] = (-gyro_bias[2]/4  >> 8) & 0xFF;
    data[5] = (-gyro_bias[2]/4)       & 0xFF;

    // Push gyro biases to hardware registers
    MPU9X50_TransmitByte(handle, XG_OFFS_USRH, data[0]);
    MPU9X50_TransmitByte(handle, XG_OFFS_USRL, data[1]);
    MPU9X50_TransmitByte(handle, YG_OFFS_USRH, data[2]);
    MPU9X50_TransmitByte(handle, YG_OFFS_USRL, data[3]);
    MPU9X50_TransmitByte(handle, ZG_OFFS_USRH, data[4]);
    MPU9X50_TransmitByte(handle, ZG_OFFS_USRL, data[5]);

    // Construct the accelerometer biases for push to the hardware accelerometer bias registers. These registers contain
    // factory trim values which must be added to the calculated accelerometer biases; on boot up these registers will hold
    // non-zero values. In addition, bit 0 of the lower byte must be preserved since it is used for temperature
    // compensation calculations. Accelerometer bias registers expect bias input as 2048 LSB per g, so that
    // the accelerometer biases calculated above must be divided by 8.

    int32_t accel_bias_reg[3] = {0, 0, 0}; // A place to hold the factory accelerometer trim biases
    MPU9X50_Receive(handle, XA_OFFSET_H, data, 2); // Read factory accelerometer trim values
    accel_bias_reg[0] = (int16_t) ((int16_t)data[0] << 8) | data[1];
    MPU9X50_Receive(handle, YA_OFFSET_H, data, 2);
    accel_bias_reg[1] = (int16_t) ((int16_t)data[0] << 8) | data[1];
    MPU9X50_Receive(handle, ZA_OFFSET_H, data, 2);
    accel_bias_reg[2] = (int16_t) ((int16_t)data[0] << 8) | data[1];

    // Construct total accelerometer bias, including calculated average accelerometer bias from above
    accel_bias_reg[0] -= (accel_bias[0]/8); // Subtract calculated averaged accelerometer bias scaled to 2048 LSB/g (16 g full scale)
    accel_bias_reg[1] -= (accel_bias[1]/8);
    accel_bias_reg[2] -= (accel_bias[2]/8);

    data[0] = (accel_bias_reg[0] >> 8) & 0xFF;
    data[1] = (accel_bias_reg[0])      & 0xFF;
    data[2] = (accel_bias_reg[1] >> 8) & 0xFF;
    data[3] = (accel_bias_reg[1])      & 0xFF;
    data[4] = (accel_bias_reg[2] >> 8) & 0xFF;
    data[5] = (accel_bias_reg[2])      & 0xFF;

    // Push accelerometer biases to hardware registers
    MPU9X50_TransmitByte(handle, XA_OFFSET_H, data[0]);
    MPU9X50_TransmitByte(handle, XA_OFFSET_L, data[1]);
    MPU9X50_TransmitByte(handle, YA_OFFSET_H, data[2]);
    MPU9X50_TransmitByte(handle, YA_OFFSET_L, data[3]);
    MPU9X50_TransmitByte(handle, ZA_OFFSET_H, data[4]);
    MPU9X50_TransmitByte(handle, ZA_OFFSET_L, data[5]);
}

void MPU9X50_InitSlave(MPU9X50_t *const handle)
{
	// wake up device
	MPU9X50_TransmitByte(handle, PWR_MGMT_1, 0x00); // Clear sleep mode bit (6), enable all sensors
	delay(100); // Delay 100 ms for PLL to get established on x-axis gyro; should check for PLL ready interrupt

	// get stable time source
	MPU9X50_TransmitByte(handle, PWR_MGMT_1, 0x01);  // Set clock source to be PLL with x-axis gyroscope reference, bits 2:0 = 001
	delay(200);

	// Configure Gyro and Accelerometer
	// Disable FSYNC and set accelerometer and gyro bandwidth to 44 and 42 Hz, respectively;
	// DLPF_CFG = bits 2:0 = 010; this sets the sample rate at 1 kHz for both
	// Minimum delay time is 4.9 ms which sets the fastest rate at ~200 Hz
	MPU9X50_TransmitByte(handle, CONFIG, 0x06);

	// Set sample rate = gyroscope output rate/(1 + SMPLRT_DIV)
	MPU9X50_TransmitByte(handle, SMPLRT_DIV, 0x00);  // Use a 500 Hz rate; the same rate set in CONFIG above

	// Set gyroscope full scale range
	// Range selects FS_SEL and AFS_SEL are 0 - 3, so 2-bit values are left-shifted into positions 4:3
	MPU9X50_TransmitByte(handle, GYRO_CONFIG, (handle->gScale << 3)); // Set full scale range for the gyro

	// Set accelerometer configuration
	MPU9X50_TransmitByte(handle, ACCEL_CONFIG, handle->aScale << 3); // Set full scale range for the accelerometer

	// Configure FIFO
	MPU9X50_TransmitByte(handle, INT_ENABLE, 0x00); // Disable all interrupts
	MPU9X50_TransmitByte(handle, FIFO_EN, 0x00);    // Disable FIFO
	MPU9X50_TransmitByte(handle, USER_CTRL, 0x02);  // Reset I2C master and FIFO and DMP
	MPU9X50_TransmitByte(handle, USER_CTRL, 0x00);  // Disable FIFO
	MPU9X50_TransmitByte(handle, INT_PIN_CFG, 0x02);
	delay(100);

	// Configure acceleration and gyroscope for FIFO
	MPU9X50_TransmitByte(handle, FIFO_EN, 0x78); // Enable all sensors for FIFO

	// Configure Interrupts and Bypass Enable
	// Set interrupt pin active high, push-pull, and clear on read of INT_STATUS, enable I2C_BYPASS_EN so additional chips
	// can join the I2C bus and all can be controlled by the Arduino as master
	MPU9X50_TransmitByte(handle, INT_PIN_CFG, 0x00);
	MPU9X50_TransmitByte(handle, INT_ENABLE, 0x01);  // Enable data ready (bit 0) interrupt

	MPU9X50_TransmitByte(handle, USER_CTRL, 0x44);
}

void delay (unsigned long time)
{
	timingdelay =  time;
	while (timingdelay != 0);             //timingdelay is modified upon a system timer overflow in SysTick_Handler routine
}

void SysTick_Handler()
{
	if (timingdelay != 0x00)
		timingdelay--;
}

void MPU9X50_lExternalInterruptEventHandler(MPU9X50_t *const handle)
{
	int16_t accRaw[3];
	int16_t gyroRaw[3];
	uint8_t data[12];
	uint8_t mpuIntStatus;
	float gRes=0;
	float aRes=0;

	if (XMC_ERU_ETL_GetStatusFlag(handle->eru, handle->etl_config->source))
	{
		mpuIntStatus = MPU9X50_ReceiveByte(handle, INT_STATUS);

		//FIFO-Count
		MPU9X50_Receive(handle, FIFO_COUNTH, data, 2);
		uint16_t fifoCount = (((uint16_t)data[0]) << 8) | data[1];

		if ((mpuIntStatus & 0x10) || fifoCount == 1024)
		{
			//Reset FIFO
			MPU9X50_TransmitByte(handle, USER_CTRL, 0x64);
		}
		else if (mpuIntStatus & 0x01)
		{
			//Read from FIFO
			MPU9X50_Receive(handle, FIFO_R_W, data, 12);

			// Read the x/y/z adc values
			accRaw[0]=((int16_t)data[0] << 8) | data[1];
			accRaw[1]=((int16_t)data[2] << 8) | data[3];
			accRaw[2]=((int16_t)data[4] << 8) | data[5];

			// Read the x/y/z adc values
			gyroRaw[0]=((int16_t)data[6] << 8) | data[7];
			gyroRaw[1]=((int16_t)data[8] << 8) | data[9];
			gyroRaw[2]=((int16_t)data[10] << 8) | data[11];

			if (handle->state == MPU9X50_STATE_RUNNING)
			{
				switch (handle->aScale)
				{
					// Possible accelerometer scales (and their register bit settings) are:
					// 2 Gs (00), 4 Gs (01), 8 Gs (10), and 16 Gs  (11).
					// Here's a bit of an algorith to calculate DPS/(ADC tick) based on that 2-bit value:
					case AFS_2G:
						aRes = 2.0/32768.0;
						break;
					case AFS_4G:
						aRes = 4.0/32768.0;
						break;
					case AFS_8G:
						aRes = 8.0/32768.0;
						break;
					case AFS_16G:
						aRes = 16.0/32768.0;
						break;
				}

				// Now we'll calculate the accleration value into actual g's
				handle->acc[0] = ((float)accRaw[0])*aRes;  // get actual g value, this depends on scale being set
				handle->acc[1] = ((float)accRaw[1])*aRes;
				handle->acc[2] = ((float)accRaw[2])*aRes;

				switch (handle->gScale)
				{
					// Possible gyro scales (and their register bit settings) are:
					// 250 DPS (00), 500 DPS (01), 1000 DPS (10), and 2000 DPS  (11).
					// Here's a bit of an algorith to calculate DPS/(ADC tick) based on that 2-bit value:
					case GFS_250DPS:
						gRes = 250.0/32768.0;
						break;
					case GFS_500DPS:
						gRes = 500.0/32768.0;
						break;
					case GFS_1000DPS:
						gRes = 1000.0/32768.0;
						break;
					case GFS_2000DPS:
						gRes = 2000.0/32768.0;
						break;
				}

				// Calculate the gyro value into actual degrees per s
				handle->gyro[0] = ((float)gyroRaw[0])*gRes;  // get actual gyro value, this depends on scale being set
				handle->gyro[1] = ((float)gyroRaw[1])*gRes;
				handle->gyro[2] = ((float)gyroRaw[2])*gRes;
			}
			else if (handle->state == MPU9X50_STATE_CALIBRATION)
			{
				handle->calib_cnt++;

				handle->acc_bias[0]+=accRaw[0];
				handle->acc_bias[1]+=accRaw[1];

				switch (handle->aScale)
				{
					case AFS_2G:
						handle->acc_bias[2]+=accRaw[2]-16384;
						break;
					case AFS_4G:
						handle->acc_bias[2]+=accRaw[2]-8192;
						break;
					case AFS_8G:
						handle->acc_bias[2]+=accRaw[2]-4096;
						break;
					case AFS_16G:
						handle->acc_bias[2]+=accRaw[2]-2048;
						break;
				}

				handle->gyro_bias[0]+=gyroRaw[0];
				handle->gyro_bias[1]+=gyroRaw[1];
				handle->gyro_bias[2]+=gyroRaw[2];

				if (handle->calib_cnt > 1024)
				{
					switch (handle->aScale)
					{
						case AFS_2G:
							handle->acc_bias[0] = handle->acc_bias[0] >> 13;
							handle->acc_bias[1] = handle->acc_bias[1] >> 13;
							handle->acc_bias[2] = handle->acc_bias[2] >> 13;
							break;
						case AFS_4G:
							handle->acc_bias[0] = handle->acc_bias[0] >> 12;
							handle->acc_bias[1] = handle->acc_bias[1] >> 12;
							handle->acc_bias[2] = handle->acc_bias[2] >> 12;
							break;
						case AFS_8G:
							handle->acc_bias[0] = handle->acc_bias[0] >> 11;
							handle->acc_bias[1] = handle->acc_bias[1] >> 11;
							handle->acc_bias[2] = handle->acc_bias[2] >> 11;
							break;
						case AFS_16G:
							handle->acc_bias[0] = handle->acc_bias[0] >> 10;
							handle->acc_bias[1] = handle->acc_bias[1] >> 10;
							handle->acc_bias[2] = handle->acc_bias[2] >> 10;
							break;
					}

				    int32_t acc_bias_reg[3] = {0, 0, 0}; // A place to hold the factory accelerometer trim biases
				    MPU9X50_Receive(handle, XA_OFFSET_H, data, 2); // Read factory accelerometer trim values
				    acc_bias_reg[0] = ((int16_t) ((int16_t)data[0] << 8) | data[1]) >> 1;
				    MPU9X50_Receive(handle, YA_OFFSET_H, data, 2);
				    acc_bias_reg[1] = ((int16_t) ((int16_t)data[0] << 8) | data[1]) >> 1;
				    MPU9X50_Receive(handle, ZA_OFFSET_H, data, 2);
				    acc_bias_reg[2] = ((int16_t) ((int16_t)data[0] << 8) | data[1]) >> 1;

				    // Construct total accelerometer bias, including calculated average accelerometer bias from above
				    acc_bias_reg[0] -= handle->acc_bias[0]; // Subtract calculated averaged accelerometer bias scaled to 2048 LSB/g (16 g full scale)
				    acc_bias_reg[1] -= handle->acc_bias[1];
				    acc_bias_reg[2] -= handle->acc_bias[2];

				    acc_bias_reg[0] = acc_bias_reg[0] << 1;
				    acc_bias_reg[1] = acc_bias_reg[1] << 1;
				    acc_bias_reg[2] = acc_bias_reg[2] << 1;

				    data[0] = (acc_bias_reg[0] >> 8) & 0xFF;
				    data[1] = (acc_bias_reg[0])      & 0xFF;
				    data[2] = (acc_bias_reg[1] >> 8) & 0xFF;
				    data[3] = (acc_bias_reg[1])      & 0xFF;
				    data[4] = (acc_bias_reg[2] >> 8) & 0xFF;
				    data[5] = (acc_bias_reg[2])      & 0xFF;

				    // Push accelerometer biases to hardware registers
				    MPU9X50_TransmitByte(handle, XA_OFFSET_H, data[0]);
				    MPU9X50_TransmitByte(handle, XA_OFFSET_L, data[1]);
				    MPU9X50_TransmitByte(handle, YA_OFFSET_H, data[2]);
				    MPU9X50_TransmitByte(handle, YA_OFFSET_L, data[3]);
				    MPU9X50_TransmitByte(handle, ZA_OFFSET_H, data[4]);
				    MPU9X50_TransmitByte(handle, ZA_OFFSET_L, data[5]);

				    switch (handle->gScale)
				    {
				    	case GFS_250DPS:
				    		handle->gyro_bias[0]=-(handle->gyro_bias[0]>>12);
				    		handle->gyro_bias[1]=-(handle->gyro_bias[1]>>12);
				    		handle->gyro_bias[2]=-(handle->gyro_bias[2]>>12);
							break;
						case GFS_500DPS:
							handle->gyro_bias[0]=-(handle->gyro_bias[0]>>11);
							handle->gyro_bias[1]=-(handle->gyro_bias[1]>>11);
							handle->gyro_bias[2]=-(handle->gyro_bias[2]>>11);
							break;
						case GFS_1000DPS:
							handle->gyro_bias[0]=-(handle->gyro_bias[0]>>10);
							handle->gyro_bias[1]=-(handle->gyro_bias[1]>>10);
							handle->gyro_bias[2]=-(handle->gyro_bias[2]>>10);
							break;
						case GFS_2000DPS:
							handle->gyro_bias[0]=-(handle->gyro_bias[0]>>9);
							handle->gyro_bias[1]=-(handle->gyro_bias[1]>>9);
							handle->gyro_bias[2]=-(handle->gyro_bias[2]>>9);
							break;
					}

				    // Construct the gyro biases for push to the hardware gyro bias registers, which are reset to zero upon device startup
				    data[0] = (handle->gyro_bias[0]  >> 8) & 0xFF; // Divide by 4 to get 32.9 LSB per deg/s to conform to expected bias input format
				    data[1] = (handle->gyro_bias[0])       & 0xFF; // Biases are additive, so change sign on calculated average gyro biases
				    data[2] = (handle->gyro_bias[1]  >> 8) & 0xFF;
				    data[3] = (handle->gyro_bias[1])       & 0xFF;
				    data[4] = (handle->gyro_bias[2]  >> 8) & 0xFF;
				    data[5] = (handle->gyro_bias[2])       & 0xFF;

				    // Push gyro biases to hardware registers
				    MPU9X50_TransmitByte(handle, XG_OFFS_USRH, data[0]);
				    MPU9X50_TransmitByte(handle, XG_OFFS_USRL, data[1]);
				    MPU9X50_TransmitByte(handle, YG_OFFS_USRH, data[2]);
				    MPU9X50_TransmitByte(handle, YG_OFFS_USRL, data[3]);
				    MPU9X50_TransmitByte(handle, ZG_OFFS_USRH, data[4]);
				    MPU9X50_TransmitByte(handle, ZG_OFFS_USRL, data[5]);

					handle->state = MPU9X50_STATE_RUNNING;
					handle->calib_cnt=0;
				}
			}
		}
		XMC_ERU_ETL_ClearStatusFlag(handle->eru, handle->etl_config->source);
	}
}
