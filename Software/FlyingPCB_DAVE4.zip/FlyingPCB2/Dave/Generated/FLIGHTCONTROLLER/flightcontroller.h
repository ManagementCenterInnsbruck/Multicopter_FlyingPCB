#ifndef FLIGHTCONTROLLER_H_
#define FLIGHTCONTROLLER_H_
/***********************************************************************************************************************
 * HEADER FILES
 **********************************************************************************************************************/

#include <xmc_ccu4.h>
#include "xmc_scu.h"
#include <xmc_gpio.h>
#include <DAVE_common.h>
#include <math.h>
#include <probe_scope.h>
#include "../BC_CCU8/bc_ccu8.h"
#include "../BC_CCU4/bc_ccu4.h"
#include "../MPU9X50/mpu9x50.h"
#include "../REMOTECONTROL/remotecontrol.h"
#include "../GLOBAL_CCU4/global_ccu4.h"
#include "GLOBAL_ADC/global_adc.h"
#include "flightcontroller_conf.h"

#if (!((XMC_LIB_MAJOR_VERSION == 2U) && \
       (XMC_LIB_MINOR_VERSION >= 0U) && \
       (XMC_LIB_PATCH_VERSION >= 0U)))
#error "FLIGHTCONTROLLER requires XMC Peripheral Library v2.0.0 or higher"
#endif


/**
 * @ingroup FLIGHTCONTROLLER_constants
 * @{
 */
/***********************************************************************************************************************
 * MACROS
 **********************************************************************************************************************/
#define GYROMEASERROR	M_PI * (40.0f / 180.0f)
#define BETA __builtin_sqrtf(3.0f / 4.0f) * GYROMEASERROR

#define DEG_TO_RAD 0.017453292519943295769236907684886f
#define RAD_TO_DEG 57.295779513082320876798154814105f
/**
 * @}
 */

 /**********************************************************************************************************************
 * ENUMS
 **********************************************************************************************************************/
 /**
  * @ingroup FLIGHTCONTROLLER_enumerations
  * @{
  */

/**
 * State of the APP
 */

typedef enum FLIGHTCONTROLLER_STATE
{
	FLIGHTCONTROLLER_UNINITIALIZED,              /*!<default state after power on reset. APP goes to UNINITIALIZED state after execution of the Deinit function.*/
	FLIGHTCONTROLLER_INITIALIZED,                /*!<APP is in INITIALIZED state after execution of the Init function*/
	FLIGHTCONTROLLER_RUNNING,                    /*!<APP is in RUNNING state after execution of the Start function.*/
	FLIGHTCONTROLLER_STOPPED                     /*!<APP is in STOPPED state after execution of the Stop function.*/
}FLIGHTCONTROLLER_STATE_t;

/**
 * Status of the APP which can be occured during initialization.
 */
typedef enum FLIGHTCONTROLLER_STATUS
{
	FLIGHTCONTROLLER_STATUS_SUCCESS,              /*!< APP status ok*/
	FLIGHTCONTROLLER_STATUS_FAILURE,              /*!< APP status failure*/
	FLIGHTCONTROLLER_INVALID_PARAM,               /*!< Input parameter is out of range.*/
	FLIGHTCONTROLLER_OPERATION_NOT_ALLOWED        /*!< Operation is not allowed in the current state of the APP */
} FLIGHTCONTROLLER_STATUS_t;

typedef enum FLIGHTCONTROLLER_FILTER
{
	FLIGHTCONTROLLER_FILTER_MADWICK,
	FLIGHTCONTROLLER_FILTER_KALMAN,
}FLIGHTCONTROLLER_FILTER_t;

/**
 * @}
 */

/**********************************************************************************************************************
* DATA STRUCTURES
**********************************************************************************************************************/
/**
  * @ingroup FLIGHTCONTROLLER_datastructures
  * @{
  */

typedef struct FLIGHTCONTROLLER_KALMAN
{
	float Q[2];
	float R[2];

	float x[2];
	float P[2][2];

	float T;

}FLIGHTCONTROLLER_KALMAN_t;

typedef struct FLIGHTCONTROLLER_DC_BUS_CHANNEL
{
	XMC_VADC_CHANNEL_CONFIG_t *ch_handle; /**< This holds the VADC Channel LLD struct*/
	XMC_VADC_RESULT_CONFIG_t *res_handle; /**< This hold the VADC LLD Result handler*/
	XMC_VADC_GROUP_t *group_handle; 		/**< This holds the group to which the channel belongs*/
	uint8_t group_index; 					/**< This holds the group index*/
	uint8_t ch_num; 						/**< This Holds the Channel Number*/
} FLIGHTCONTROLLER_DC_BUS_CHANNEL_t;

/**
 * PID-Control parameter
 */
typedef struct FLIGHTCONTROLLER_PID
{
	float	a[2];				/**< denominator coefficients */
	float	b[3];				/**< nominator coefficients */
	float	x[2];				/**< control coefficients */
	float	P;				/**< P-Gain */
	float	I;				/**< I-Gain */
	float	D;				/**< D-Gain */
	float	N;				/**< N-Gain */
	uint8_t	n;				/**< control order */
}FLIGHTCONTROLLER_PID_t;

/**
 * GPIO Port and Pin
 */
typedef struct FLIGHTCONTROLLER_GPIO
{
	XMC_GPIO_PORT_t *const port;      /**< Port */
	const uint8_t pin;                /**< Pin */
} FLIGHTCONTROLLER_GPIO_t;

/**
 *  CCU4-CC4 slice identifier data
 */
typedef struct FLIGHTCONTROLLER_SLICE
{
	XMC_CCU4_MODULE_t               *module_ptr;   /*!< CCU4 module initialization structure pointer*/
	XMC_CCU4_SLICE_t  				*slice_ptr;    /**< CCU4 CC4 pointer */
	uint8_t            				slice_number;  /**< The slice identifier - 0 index based*/
} FLIGHTCONTROLLER_SLICE_t;

/**
 * Interrupt configuration
 */
typedef struct FLIGHTCONTROLLER_INTERRUPT
{
	const IRQn_Type node;       	/**< Mapped NVIC Node */
	const uint8_t priority; 	  	/**< Node Interrupt Priority */
	const uint8_t subpriority;  	/**< Node Interrupt SubPriority only valid for XMC4x */
} FLIGHTCONTROLLER_INTERRUPT_t;

/**
 * This structure holds the GUI configurable parameters of this APP.
 */
typedef struct FLIGHTCONTROLLER_Config
{
	uint32_t                               	module_freq;            /*!< Represents module frequency*/
	uint32_t                               	frequency_max;          /*!< Max period value*/
	uint32_t                               	frequency_min;          /*!< Min period value*/
	uint32_t                               	event_sr_selector; 	   /*!< mask for the SRS register*/
	uint16_t                               	shadowtransfer;		   /*!< Shadow transfer mask as per CCU4 slices allocated*/
	float								   	freq;
	float								   	period;
	float									speed_saturation_max;
	float									speed_saturation_min;
	float									throttle_min;
	float									scale_throttle_from;
	float									scale_throttle_to;
	float									scale_rudder_from;
	float									scale_rudder_to;
	float									scale_elevator_from;
	float									scale_elevator_to;
	float									scale_aileron_from;
	float									scale_aileron_to;
	FLIGHTCONTROLLER_FILTER_t				filter_mode;
}FLIGHTCONTROLLER_Config_t;

/**
  * This structure holds the BC parameters which change at run
  * time.
  */
typedef struct FLIGHTCONTROLLER
{
	const	FLIGHTCONTROLLER_SLICE_t*                   const  	control_ptr;	     	/*!< Pointer to ccu4 phase timer init configuration structure*/
			GLOBAL_CCU4_t*							 	const	globalccu4_ptr;			/*!< Pointer to the GLOBAL_CCU4 APP handle structure*/
	const  	XMC_CCU4_SLICE_COMPARE_CONFIG_t*    		const  	control_timerinit_ptr;  /*!< CCU4 timer init structure pointer */
			FLIGHTCONTROLLER_STATE_t							state;					/*!< State of the APP */
	const  	FLIGHTCONTROLLER_Config_t*                  const  	config_ptr;           	/*!< pointer to the Dynamic Handle of the APP */
	const   FLIGHTCONTROLLER_INTERRUPT_t*				const	int_control;			/*!< Pointer to commutation intterupt */
			BC_CCU8_t*									const	motor_1_ccu8;
			BC_CCU8_t*									const	motor_2_ccu8;
			BC_CCU4_t*									const	motor_3_ccu4;
			BC_CCU4_t*									const	motor_4_ccu4;
			MPU9X50_t*									const	mpu;
			REMOTECONTROL_t*							const	rc;

			FLIGHTCONTROLLER_PID_t*					const 	controllers[3];

	const	FLIGHTCONTROLLER_DC_BUS_CHANNEL_t*			const	channel_ptr;
	const	XMC_VADC_BACKGROUND_CONFIG_t*				const	backgnd_config_handle;
	const  	FLIGHTCONTROLLER_INTERRUPT_t*               const	req_src_intr_handle;
	const	XMC_VADC_GLOBAL_CLASS_t*					const	iclass_config_handle;
			uint8_t												iclass_num;
	const	XMC_VADC_SR_t										srv_req_node;
			FLIGHTCONTROLLER_KALMAN_t*					const	kalman[2];
			GLOBAL_ADC_t*								const	global_adc;

			uint16_t   			                                period_reg;    		    /*!< This variable gives the period value*/
			float												q[4];					/*!< This variable holds quaternions*/
			float												angles[3];				/*!< ROLL, PITCH, YAW*/
			float												angles_acc[2];
			float												rc_data[4];
			float												rc_data_prev[4];
			float												rc_data_int[4];
			float												u[4];
			float												speed[4];
			uint8_t												int_cnt;
			uint8_t												int_num;
}FLIGHTCONTROLLER_t;

/**
 * @}
 */

#ifdef __cplusplus
extern "C" {
#endif
/**
 * @ingroup FLIGHTCONTROLLER_apidoc
 * @{
 */
  /***********************************************************************************************************************
   * API Prototypes
   **********************************************************************************************************************/
/**
 * @brief Get FLIGHTCONTROLLER APP version
 * @return DAVE_APP_VERSION_t APP version information (major, minor and patch number)
 *
 * \par<b>Description: </b><br>
 * The function can be used to check application software compatibility with a
 * specific version of the APP.
 *
 * Example Usage:
 *
 * @code
 * #include <DAVE.h>
 *
 * int main(void) {
 *   DAVE_STATUS_t init_status;
 *   DAVE_APP_VERSION_t version;
 *
 *   // Initialize FLIGHTCONTROLLER APP:
 *   // FLIGHTCONTROLLER_Init() is called from within DAVE_Init().
 *   init_status = DAVE_Init();
 *
 *   version = FLIGHTCONTROLLER_GetAppVersion();
 *   if (version.major != 1U) {
 *     // Probably, not the right version.
 *   }
 *
 *   // More code here
 *   while(1) {
 *
 *   }
 *   return (0);
 * }
 * @endcode<BR>
 */

DAVE_APP_VERSION_t FLIGHTCONTROLLER_GetAppVersion(void);

/**
 * @brief Initializes APP with configuration associated with APP struture through HandlePtr.
 * @param HandlePtr Pointer of the APP user configuration
 * @return @ref FLIGHTCONTROLLER_STATUS_t It returns FLIGHTCONTROLLER_STATUS_FAILURE when any of the consumed low level APP \n
 * init function is getting failed<BR>
 * \par<b>Description:</b><br>
 *  Initializes APP with configuration associated with APP struture through HandlePtr. \n
 *  It is the first function to be called to invoke this APP.<br>
 *  Initializes CCU4 module.\n
 * Example Usage:
 * @code
   #include <DAVE.h>
   int main (void)
   {
     DAVE_STATUS_t status;
     status = DAVE_Init(); //FLIGHTCONTROLLER_Init() called by DAVE_Init()
     while(1);
     return 0;
   }
 * @endcode
 * \par<b>Related APIs:</b><br>
 *  FLIGHTCONTROLLER_Start()<br>
 */
FLIGHTCONTROLLER_STATUS_t FLIGHTCONTROLLER_Init(FLIGHTCONTROLLER_t* HandlePtr);

void FLIGHTCONTROLLER_lControlEventHandler(FLIGHTCONTROLLER_t* HandlePtr);
void FLIGHTCONTROLLER_lDCBusMeasurmentEventHandler(FLIGHTCONTROLLER_t* HandlePtr);

FLIGHTCONTROLLER_STATUS_t FLIGHTCONTROLLER_CalculateReferenceValues(FLIGHTCONTROLLER_t* HandlePtr);
void FLIGHTCONTROLLER_CalculateAnglesAndAngleRate(FLIGHTCONTROLLER_t* HandlePtr);
void FLIGHTCONTROLLER_FilterUpdate(FLIGHTCONTROLLER_t* HandlePtr);

void FLIGHTCONTROLLER_Init_PID_Control(FLIGHTCONTROLLER_t* HandlePtr, FLIGHTCONTROLLER_PID_t* pid);
void FLIGHTCONTROLLER_Init_P_Control(FLIGHTCONTROLLER_t* HandlePtr, FLIGHTCONTROLLER_PID_t* pid);
float FLIGHTCONTROLLER_PID_Control(FLIGHTCONTROLLER_PID_t* pid, float r, float y);
void FLIGHTCONTROLLER_CreateMotorSpeedsPercent(FLIGHTCONTROLLER_t* HandlePtr);

float FLIGHTCONTROLLER_Kalman_Step(FLIGHTCONTROLLER_KALMAN_t* kf, float phi, float omega);

#include "flightcontroller_extern.h"

#ifdef __cplusplus
}
#endif

#endif /* FLIGHTCONTROLLER_H_ */

