/***********************************************************************************************************************
 * HEADER FILES
 **********************************************************************************************************************/
#include "flightcontroller.h"

static uint8_t newControlParameter=0;

/***********************************************************************************************************************
 * MACROS
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * LOCAL DATA
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * LOCAL ROUTINES
 **********************************************************************************************************************/

/* App API to retrieve the App version info */
DAVE_APP_VERSION_t FLIGHTCONTROLLER_GetAppVersion(void)
{
	DAVE_APP_VERSION_t version;

	version.major = FLIGHTCONTROLLER_MAJOR_VERSION;
	version.minor = FLIGHTCONTROLLER_MINOR_VERSION;
	version.patch = FLIGHTCONTROLLER_PATCH_VERSION;

	return version;
}

/**
 * This function initializes all the three CCU4 phases as per the user configurations
 */
FLIGHTCONTROLLER_STATUS_t FLIGHTCONTROLLER_Init(FLIGHTCONTROLLER_t* HandlePtr)
{
	uint32_t init_status = (uint32_t)FLIGHTCONTROLLER_STATUS_SUCCESS;

	XMC_ASSERT("FLIGHTCONTROLLER_Init:NULL Handle Pointer",
				(HandlePtr != (FLIGHTCONTROLLER_t *)NULL));

	if (FLIGHTCONTROLLER_UNINITIALIZED == HandlePtr->state)
	{
		init_status |= (uint32_t)BC_CCU8_Init(HandlePtr->motor_1_ccu8);
		init_status |= (uint32_t)BC_CCU8_Init(HandlePtr->motor_2_ccu8);
		init_status |= (uint32_t)BC_CCU4_Init(HandlePtr->motor_3_ccu4);
		init_status |= (uint32_t)BC_CCU4_Init(HandlePtr->motor_4_ccu4);

		init_status |= (uint32_t)MPU9X50_Init(HandlePtr->mpu);
		init_status |= (uint32_t)REMOTECONTROL_Init(HandlePtr->rc);

		init_status |= (uint32_t)GLOBAL_CCU4_Init(HandlePtr->globalccu4_ptr);
		init_status |= (uint32_t)GLOBAL_ADC_Init(HandlePtr->global_adc);
		if (init_status == FLIGHTCONTROLLER_STATUS_SUCCESS)
		{
			XMC_CCU4_SLICE_CompareInit(HandlePtr->control_ptr->slice_ptr, HandlePtr->control_timerinit_ptr);
			XMC_CCU4_SLICE_SetTimerPeriodMatch(HandlePtr->control_ptr->slice_ptr, HandlePtr->period_reg);
			XMC_CCU4_SLICE_SetInterruptNode(HandlePtr->control_ptr->slice_ptr,
											XMC_CCU4_SLICE_IRQ_ID_PERIOD_MATCH,
											(XMC_CCU4_SLICE_SR_ID_t)HandlePtr->config_ptr->event_sr_selector);
			XMC_CCU4_SLICE_EnableEvent(HandlePtr->control_ptr->slice_ptr, XMC_CCU4_SLICE_IRQ_ID_PERIOD_MATCH);

			NVIC_SetPriority(HandlePtr->int_control->node, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), HandlePtr->int_control->priority, HandlePtr->int_control->subpriority));
			NVIC_EnableIRQ(HandlePtr->int_control->node);

			XMC_CCU4_EnableShadowTransfer(HandlePtr->control_ptr->module_ptr, HandlePtr->config_ptr->shadowtransfer);
			XMC_CCU4_EnableClock(HandlePtr->control_ptr->module_ptr, HandlePtr->control_ptr->slice_number);

			HandlePtr->q[0]=1;
			HandlePtr->q[1]=0;
			HandlePtr->q[2]=0;
			HandlePtr->q[3]=0;

			ProbeScope_Init(HandlePtr->config_ptr->freq);

			FLIGHTCONTROLLER_Init_PID_Control(HandlePtr, HandlePtr->controllers[0]);
			FLIGHTCONTROLLER_Init_PID_Control(HandlePtr, HandlePtr->controllers[1]);
			FLIGHTCONTROLLER_Init_P_Control(HandlePtr, HandlePtr->controllers[2]);

			/*DC-Bus Measurement*/
			XMC_VADC_GLOBAL_InputClassInit(HandlePtr->global_adc->module_ptr, *HandlePtr->iclass_config_handle, XMC_VADC_GROUP_CONV_STD, HandlePtr->iclass_num);
			XMC_VADC_GLOBAL_BackgroundInit(HandlePtr->global_adc->module_ptr, HandlePtr->backgnd_config_handle);

			XMC_VADC_GROUP_ChannelInit(HandlePtr->channel_ptr->group_handle,(uint32_t)HandlePtr->channel_ptr->ch_num, HandlePtr->channel_ptr->ch_handle);
			XMC_VADC_GROUP_ResultInit(HandlePtr->channel_ptr->group_handle, (uint32_t)HandlePtr->channel_ptr->ch_handle->result_reg_number, HandlePtr->channel_ptr->res_handle);

			XMC_VADC_GLOBAL_BackgroundAddChannelToSequence(HandlePtr->global_adc->module_ptr, (uint32_t)HandlePtr->channel_ptr->group_index, (uint32_t)HandlePtr->channel_ptr->ch_num);
			XMC_VADC_GLOBAL_BackgroundSetReqSrcEventInterruptNode(HandlePtr->global_adc->module_ptr, (XMC_VADC_SR_t) HandlePtr->srv_req_node);

		    NVIC_SetPriority((IRQn_Type)HandlePtr->req_src_intr_handle->node,
		                        NVIC_EncodePriority(NVIC_GetPriorityGrouping(),
		                        HandlePtr->req_src_intr_handle->priority, HandlePtr->req_src_intr_handle->subpriority));
		    NVIC_EnableIRQ((IRQn_Type)HandlePtr->req_src_intr_handle->node);

		    XMC_VADC_GLOBAL_BackgroundTriggerConversion(HandlePtr->global_adc->module_ptr);

			XMC_CCU4_SLICE_StartTimer(HandlePtr->control_ptr->slice_ptr);
		}
		else
			init_status = FLIGHTCONTROLLER_STATUS_FAILURE;

		HandlePtr->state = FLIGHTCONTROLLER_INITIALIZED;
	}

	return ((FLIGHTCONTROLLER_STATUS_t)init_status);
}

void FLIGHTCONTROLLER_lControlEventHandler(FLIGHTCONTROLLER_t* HandlePtr)
{
	if (HandlePtr->control_ptr->slice_ptr->INTS & CCU4_CC4_INTS_PMUS_Msk)
	{
		//RC-Data
		if (FLIGHTCONTROLLER_CalculateReferenceValues(HandlePtr) == FLIGHTCONTROLLER_STATUS_SUCCESS)
		{
			HandlePtr->u[0]=HandlePtr->rc_data_int[0];
			//MPU-Data
			FLIGHTCONTROLLER_CalculateAnglesAndAngleRate(HandlePtr);
			// Roll-Control
			HandlePtr->u[1]=FLIGHTCONTROLLER_PID_Control(HandlePtr->controllers[0], HandlePtr->rc_data_int[1], HandlePtr->angles[0]);
			// Pitch-Control
			HandlePtr->u[2]=FLIGHTCONTROLLER_PID_Control(HandlePtr->controllers[1], HandlePtr->rc_data_int[2], HandlePtr->angles[1]);
			// Yaw-Control
			HandlePtr->u[3]=FLIGHTCONTROLLER_PID_Control(HandlePtr->controllers[2], HandlePtr->rc_data_int[3], HandlePtr->angles[2]);

			FLIGHTCONTROLLER_CreateMotorSpeedsPercent(HandlePtr);

			// Motor 1
			if (HandlePtr->u[0] >= HandlePtr->config_ptr->throttle_min && (HandlePtr->motor_1_ccu8->state == BC_CCU8_INITIALIZED ||
																		   HandlePtr->motor_1_ccu8->state == BC_CCU8_STOPPED))
				BC_CCU8_Start(HandlePtr->motor_1_ccu8);
			else if (HandlePtr->u[0] < HandlePtr->config_ptr->throttle_min && (HandlePtr->motor_1_ccu8->state == BC_CCU8_RUNNING ||
																	           HandlePtr->motor_1_ccu8->state == BC_CCU8_RAMP))
				BC_CCU8_Stop(HandlePtr->motor_1_ccu8);

			else if (HandlePtr->motor_1_ccu8->state == BC_CCU8_RUNNING)
				BC_CCU8_SetMotorSpeedPercent(HandlePtr->motor_1_ccu8, HandlePtr->speed[0]);

			// Motor 2
			if (HandlePtr->u[0] >= HandlePtr->config_ptr->throttle_min && (HandlePtr->motor_2_ccu8->state == BC_CCU8_INITIALIZED ||
																           HandlePtr->motor_2_ccu8->state == BC_CCU8_STOPPED))
				BC_CCU8_Start(HandlePtr->motor_2_ccu8);
			else if (HandlePtr->u[0] < HandlePtr->config_ptr->throttle_min && (HandlePtr->motor_2_ccu8->state == BC_CCU8_RUNNING ||
																	       HandlePtr->motor_2_ccu8->state == BC_CCU8_RAMP))
				BC_CCU8_Stop(HandlePtr->motor_2_ccu8);

			else if (HandlePtr->motor_2_ccu8->state == BC_CCU8_RUNNING)
				BC_CCU8_SetMotorSpeedPercent(HandlePtr->motor_2_ccu8, HandlePtr->speed[1]);

			// Motor 3
			if (HandlePtr->u[0] >= HandlePtr->config_ptr->throttle_min && (HandlePtr->motor_3_ccu4->state == BC_CCU4_INITIALIZED ||
																           HandlePtr->motor_3_ccu4->state == BC_CCU4_STOPPED))
				BC_CCU4_Start(HandlePtr->motor_3_ccu4);
			else if (HandlePtr->u[0] < HandlePtr->config_ptr->throttle_min && (HandlePtr->motor_3_ccu4->state == BC_CCU4_RUNNING ||
																	           HandlePtr->motor_3_ccu4->state == BC_CCU4_RAMP))
				BC_CCU4_Stop(HandlePtr->motor_3_ccu4);

			else if (HandlePtr->motor_3_ccu4->state == BC_CCU4_RUNNING)
				BC_CCU4_SetMotorSpeedPercent(HandlePtr->motor_3_ccu4, HandlePtr->speed[2]);

			// Motor 4
			if (HandlePtr->u[0] >= HandlePtr->config_ptr->throttle_min && (HandlePtr->motor_4_ccu4->state == BC_CCU4_INITIALIZED ||
															               HandlePtr->motor_4_ccu4->state == BC_CCU4_STOPPED))
				BC_CCU4_Start(HandlePtr->motor_4_ccu4);
			else if (HandlePtr->u[0] < HandlePtr->config_ptr->throttle_min && (HandlePtr->motor_4_ccu4->state == BC_CCU4_RUNNING ||
																	           HandlePtr->motor_4_ccu4->state == BC_CCU4_RAMP))
				BC_CCU4_Stop(HandlePtr->motor_4_ccu4);

			else if (HandlePtr->motor_4_ccu4->state == BC_CCU4_RUNNING)
				BC_CCU4_SetMotorSpeedPercent(HandlePtr->motor_4_ccu4, HandlePtr->speed[3]);
		}
		else
		{
			if (HandlePtr->motor_1_ccu8->state == BC_CCU8_RUNNING || HandlePtr->motor_1_ccu8->state == BC_CCU8_RAMP)
				BC_CCU8_Stop(HandlePtr->motor_1_ccu8);

			if (HandlePtr->motor_2_ccu8->state == BC_CCU8_RUNNING || HandlePtr->motor_2_ccu8->state == BC_CCU8_RAMP)
				BC_CCU8_Stop(HandlePtr->motor_2_ccu8);

			if (HandlePtr->motor_3_ccu4->state == BC_CCU4_RUNNING || HandlePtr->motor_3_ccu4->state == BC_CCU4_RAMP)
				BC_CCU4_Stop(HandlePtr->motor_3_ccu4);

			if (HandlePtr->motor_4_ccu4->state == BC_CCU4_RUNNING || HandlePtr->motor_4_ccu4->state == BC_CCU4_RAMP)
				BC_CCU4_Stop(HandlePtr->motor_4_ccu4);
		}


		ProbeScope_Sampling();
		HandlePtr->control_ptr->slice_ptr->SWR |= ((1 << CCU4_CC4_SWR_RPM_Pos) & CCU4_CC4_SWR_RPM_Msk);
	}
}

FLIGHTCONTROLLER_STATUS_t FLIGHTCONTROLLER_CalculateReferenceValues(FLIGHTCONTROLLER_t* HandlePtr)
{
	FLIGHTCONTROLLER_STATUS_t status = FLIGHTCONTROLLER_STATUS_SUCCESS;
	float rc_data[4];

	REMOTECONTROL_STATUS_t mode = REMOTECONTROL_GetRCData(HandlePtr->rc, rc_data);

	if (mode == REMOTECONTROL_STATUS_SUCCESS)
	{
		if (HandlePtr->rc->type == REMOTECONTROL_TYPE_SATELLITE)
		{
			if (HandlePtr->rc->new_data)
			{
				for (int i=0; i<4; i++)
				HandlePtr->rc_data_prev[i]=HandlePtr->rc_data_int[i]=HandlePtr->rc_data[i];

				HandlePtr->rc_data[0] = ((float)rc_data[0]) * (HandlePtr->config_ptr->scale_throttle_to - HandlePtr->config_ptr->scale_throttle_from)/32767.0
															+ HandlePtr->config_ptr->scale_throttle_from;

				HandlePtr->rc_data[1] = -((float)rc_data[1]) * (HandlePtr->config_ptr->scale_aileron_to - HandlePtr->config_ptr->scale_aileron_from)/65535.0
															+ HandlePtr->config_ptr->scale_aileron_from + HandlePtr->config_ptr->scale_aileron_to;

				HandlePtr->rc_data[2] = ((float)rc_data[2]) * (HandlePtr->config_ptr->scale_elevator_to - HandlePtr->config_ptr->scale_elevator_from)/65535.0
															+ HandlePtr->config_ptr->scale_elevator_from + HandlePtr->config_ptr->scale_elevator_to;

				HandlePtr->rc_data[3] = ((float)rc_data[3]) * (HandlePtr->config_ptr->scale_rudder_to - HandlePtr->config_ptr->scale_rudder_from)/65535.0
															+ HandlePtr->config_ptr->scale_rudder_from + HandlePtr->config_ptr->scale_rudder_to;
			}
			else
			{
				HandlePtr->int_cnt++;

				if (HandlePtr->int_num == 0)
					HandlePtr->int_num=1;

				for (int i=0; i<4; i++)
					HandlePtr->rc_data_int[i]=(HandlePtr->rc_data[i]-HandlePtr->rc_data_prev[i])*HandlePtr->int_cnt/HandlePtr->int_num+HandlePtr->rc_data_prev[i];

			}

			HandlePtr->int_num=HandlePtr->int_cnt;
			HandlePtr->int_cnt=0;
			HandlePtr->rc->new_data=0;
		}
		else if(HandlePtr->rc->type == REMOTECONTROL_TYPE_BLUETOOTH)
		{
			HandlePtr->rc_data_int[0] = HandlePtr->rc_data[0] = rc_data[0];
			HandlePtr->rc_data_int[1] = HandlePtr->rc_data[1] = -rc_data[1];
			HandlePtr->rc_data_int[2] = HandlePtr->rc_data[2] = -rc_data[2];
			HandlePtr->rc_data_int[3] = HandlePtr->rc_data[3] = rc_data[3];
		}
	}
	else if (mode == REMOTECONTROL_STATUS_FLIGHTMODE)
	{
		HandlePtr->rc_data_int[0]=HandlePtr->rc_data[1]=HandlePtr->rc_data[2]=HandlePtr->rc_data[3]=0;

		if (rc_data[3] <= -16384 && !newControlParameter)
		{
			if (rc_data[1] > 16384)
			{
				if (rc_data[0] < 16384)
					HandlePtr->controllers[0]->D++;
				else
					HandlePtr->controllers[0]->P++;
				newControlParameter=1;
			}
			else if (rc_data[1] < -16384)
			{
				if (rc_data[0] < 16384)
					HandlePtr->controllers[0]->D--;
				else
					HandlePtr->controllers[0]->P--;
				newControlParameter=1;
			}
			if (rc_data[2] > 16384)
			{
				if (rc_data[0] < 16384)
					HandlePtr->controllers[0]->N++;
				else
					HandlePtr->controllers[2]->P++;
				newControlParameter=1;
			}
			else if (rc_data[2] < -16384)
			{
				if (rc_data[0] < 16384)
					HandlePtr->controllers[0]->N--;
				else
					HandlePtr->controllers[2]->P--;
				newControlParameter=1;
			}
			if (newControlParameter)
			{
				FLIGHTCONTROLLER_Init_PID_Control(HandlePtr, HandlePtr->controllers[0]);
				FLIGHTCONTROLLER_Init_PID_Control(HandlePtr, HandlePtr->controllers[1]);
				FLIGHTCONTROLLER_Init_P_Control(HandlePtr, HandlePtr->controllers[2]);
			}
		}
		else if (rc_data[3] >= 16384 && !newControlParameter)
		{
			if (rc_data[1] > 16384)
			{
				if (rc_data[0] < 16384)
					HandlePtr->controllers[1]->D++;
				else
					HandlePtr->controllers[1]->P++;
				newControlParameter=1;
			}
			else if (rc_data[1] < -16384)
			{
				if (rc_data[0] < 16384)
					HandlePtr->controllers[1]->D--;
				else
					HandlePtr->controllers[1]->P--;
				newControlParameter=1;
			}
			if (rc_data[2] > 16384)
			{
				HandlePtr->controllers[1]->N++;
				newControlParameter=1;
			}
			else if (rc_data[2] < -16384)
			{
				HandlePtr->controllers[1]->N--;
				newControlParameter=1;
			}
			if (newControlParameter)
			{
				FLIGHTCONTROLLER_Init_PID_Control(HandlePtr, HandlePtr->controllers[0]);
				FLIGHTCONTROLLER_Init_PID_Control(HandlePtr, HandlePtr->controllers[1]);
				FLIGHTCONTROLLER_Init_P_Control(HandlePtr, HandlePtr->controllers[2]);
			}
		}
		else if (rc_data[3] > -16384 && rc_data[3] < 16384)
			newControlParameter = 0;
	}
	else
		status = FLIGHTCONTROLLER_STATUS_FAILURE;

	return status;
}

void FLIGHTCONTROLLER_CalculateAnglesAndAngleRate(FLIGHTCONTROLLER_t* HandlePtr)
{
	if (HandlePtr->config_ptr->filter_mode == FLIGHTCONTROLLER_FILTER_MADWICK)
	{
		FLIGHTCONTROLLER_FilterUpdate(HandlePtr);
		HandlePtr->angles[0]=atan2(2.0f * (HandlePtr->q[0] * HandlePtr->q[1] + HandlePtr->q[2] * HandlePtr->q[3]),
											  HandlePtr->q[0] * HandlePtr->q[0] - HandlePtr->q[1] * HandlePtr->q[1] -
											  HandlePtr->q[2] * HandlePtr->q[2] + HandlePtr->q[3] * HandlePtr->q[3]) * RAD_TO_DEG;
		HandlePtr->angles[1]=-asin(2.0f * (HandlePtr->q[1] * HandlePtr->q[3] - HandlePtr->q[0] * HandlePtr->q[2])) * RAD_TO_DEG;
	}
	else if (HandlePtr->config_ptr->filter_mode == FLIGHTCONTROLLER_FILTER_KALMAN)
	{
		HandlePtr->angles_acc[0] = atan2(HandlePtr->mpu->acc[1], sqrt(HandlePtr->mpu->acc[1]*HandlePtr->mpu->acc[1]+HandlePtr->mpu->acc[2]*HandlePtr->mpu->acc[2])) * RAD_TO_DEG;
		HandlePtr->angles_acc[1]= atan2(HandlePtr->mpu->acc[0], sqrt(HandlePtr->mpu->acc[0]*HandlePtr->mpu->acc[0]+HandlePtr->mpu->acc[2]*HandlePtr->mpu->acc[2])) * RAD_TO_DEG;

		HandlePtr->angles[0]=FLIGHTCONTROLLER_Kalman_Step(HandlePtr->kalman[0], HandlePtr->angles_acc[0], HandlePtr->mpu->gyro[0]);
		HandlePtr->angles[1]=-FLIGHTCONTROLLER_Kalman_Step(HandlePtr->kalman[1], HandlePtr->angles_acc[1], HandlePtr->mpu->gyro[1]);
	}

	HandlePtr->angles[2]=HandlePtr->mpu->gyro[2];
}

void FLIGHTCONTROLLER_FilterUpdate(FLIGHTCONTROLLER_t* HandlePtr)
{
	// Local system variables
	float norm; // vector norm
	float SEqDot_omega_1, SEqDot_omega_2, SEqDot_omega_3, SEqDot_omega_4; // quaternion derrivative from gyroscopes elements
	float f_1, f_2, f_3; // objective function elements
	float J_11or24, J_12or23, J_13or22, J_14or21, J_32, J_33; // objective function Jacobian elements
	float SEqHatDot_1, SEqHatDot_2, SEqHatDot_3, SEqHatDot_4; // estimated direction of the gyroscope error
	// Axulirary variables to avoid reapeated calcualtions
	float halfSEq_1 = 0.5f * HandlePtr->q[0];
	float halfSEq_2 = 0.5f * HandlePtr->q[1];
	float halfSEq_3 = 0.5f * HandlePtr->q[2];
	float halfSEq_4 = 0.5f * HandlePtr->q[3];
	float twoSEq_1 = 2.0f * HandlePtr->q[0];
	float twoSEq_2 = 2.0f * HandlePtr->q[1];
	float twoSEq_3 = 2.0f * HandlePtr->q[2];
	float a_x = HandlePtr->mpu->acc[0];
	float a_y = HandlePtr->mpu->acc[1];
	float a_z = HandlePtr->mpu->acc[2];
	float w_x = HandlePtr->mpu->gyro[0]*DEG_TO_RAD;
	float w_y = HandlePtr->mpu->gyro[1]*DEG_TO_RAD;
	float w_z = HandlePtr->mpu->gyro[2]*DEG_TO_RAD;

	if (a_x == 0 && a_y == 0 && a_z == 0)
		return;

	// Normalise the accelerometer measurement
	norm = sqrt(a_x * a_x + a_y * a_y + a_z * a_z);
	a_x /= norm;
	a_y /= norm;
	a_z /= norm;
	// Compute the objective function and Jacobian
	f_1 = twoSEq_2 * HandlePtr->q[3] - twoSEq_1 * HandlePtr->q[2] - a_x;
	f_2 = twoSEq_1 * HandlePtr->q[1] + twoSEq_3 * HandlePtr->q[3] - a_y;
	f_3 = 1.0f - twoSEq_2 * HandlePtr->q[1] - twoSEq_3 * HandlePtr->q[2] - a_z;
	J_11or24 = twoSEq_3; // J_11 negated in matrix multiplication
	J_12or23 = 2.0f * HandlePtr->q[3];
	J_13or22 = twoSEq_1; // J_12 negated in matrix multiplication
	J_14or21 = twoSEq_2;
	J_32 = 2.0f * J_14or21; // negated in matrix multiplication
	J_33 = 2.0f * J_11or24; // negated in matrix multiplication
	// Compute the gradient (matrix multiplication)
	SEqHatDot_1 = J_14or21 * f_2 - J_11or24 * f_1;
	SEqHatDot_2 = J_12or23 * f_1 + J_13or22 * f_2 - J_32 * f_3;
	SEqHatDot_3 = J_12or23 * f_2 - J_33 * f_3 - J_13or22 * f_1;
	SEqHatDot_4 = J_14or21 * f_1 + J_11or24 * f_2;
	// Normalise the gradient
	norm = sqrt(SEqHatDot_1 * SEqHatDot_1 + SEqHatDot_2 * SEqHatDot_2 + SEqHatDot_3 * SEqHatDot_3 + SEqHatDot_4 * SEqHatDot_4);
	SEqHatDot_1 /= norm;
	SEqHatDot_2 /= norm;
	SEqHatDot_3 /= norm;
	SEqHatDot_4 /= norm;
	// Compute the quaternion derrivative measured by gyroscopes
	SEqDot_omega_1 = -halfSEq_2 * w_x - halfSEq_3 * w_y - halfSEq_4 * w_z;
	SEqDot_omega_2 = halfSEq_1 * w_x + halfSEq_3 * w_z - halfSEq_4 * w_y;
	SEqDot_omega_3 = halfSEq_1 * w_y - halfSEq_2 * w_z + halfSEq_4 * w_x;
	SEqDot_omega_4 = halfSEq_1 * w_z + halfSEq_2 * w_y - halfSEq_3 * w_x;
	// Compute then integrate the estimated quaternion derrivative
	HandlePtr->q[0] += (SEqDot_omega_1 - (BETA * SEqHatDot_1)) * HandlePtr->config_ptr->period;
	HandlePtr->q[1] += (SEqDot_omega_2 - (BETA * SEqHatDot_2)) * HandlePtr->config_ptr->period;
	HandlePtr->q[2] += (SEqDot_omega_3 - (BETA * SEqHatDot_3)) * HandlePtr->config_ptr->period;
	HandlePtr->q[3] += (SEqDot_omega_4 - (BETA * SEqHatDot_4)) * HandlePtr->config_ptr->period;
	// Normalise quaternion
	norm = sqrt(HandlePtr->q[0] * HandlePtr->q[0] + HandlePtr->q[1] * HandlePtr->q[1] + HandlePtr->q[2] * HandlePtr->q[2] + HandlePtr->q[3] * HandlePtr->q[3]);
	HandlePtr->q[0] /= norm;
	HandlePtr->q[1] /= norm;
	HandlePtr->q[2] /= norm;
	HandlePtr->q[3] /= norm;
}

float FLIGHTCONTROLLER_Kalman_Step(FLIGHTCONTROLLER_KALMAN_t* kf, float phi, float omega)
{
	float x_p[2];
	float P_p[2][2];
	float S[2][2];
	float K[2][2];

	float z[2];

	float det_S;

	//Time update
	x_p[0]=kf->x[0]-kf->T*kf->x[1];
	x_p[1]=kf->x[1];

	P_p[0][0]=kf->P[0][0]-kf->P[1][0]*kf->T-kf->P[0][1]*kf->T+kf->P[1][1]*kf->T*kf->T+kf->Q[0];
	P_p[0][1]=kf->P[0][1]-kf->P[1][1]*kf->T;
	P_p[1][0]=kf->P[1][0]-kf->P[1][1]*kf->T;
	P_p[1][1]=kf->P[1][1]+kf->Q[1];

	//Measurement update
	S[0][0]=P_p[0][0]+kf->R[0];
	S[0][1]=P_p[0][1];
	S[1][0]=P_p[1][0];
	S[1][1]=P_p[1][1]+kf->R[1];

	det_S=S[0][0]*S[1][1]-S[0][1]*S[1][0];
	K[0][0]=(+P_p[0][0]*S[1][1]-P_p[0][1]*S[1][0])/det_S;
	K[0][1]=(-P_p[0][0]*S[0][1]+P_p[0][1]*S[0][0])/det_S;
	K[1][0]=(+P_p[1][0]*S[1][1]-P_p[1][1]*S[1][0])/det_S;
	K[1][1]=(-P_p[1][0]*S[0][1]+P_p[1][1]*S[0][0])/det_S;

	z[0]=phi-x_p[0];
	z[1]=omega-x_p[1];
    kf->x[0]=x_p[0]+K[0][0]*z[0]+K[0][1]*z[1];
    kf->x[1]=x_p[1]+K[1][0]*z[0]+K[1][1]*z[1];

    kf->P[0][0]=P_p[0][0]-K[0][0]*P_p[0][0]-K[0][1]*P_p[1][0];
    kf->P[0][1]=P_p[0][1]-K[0][0]*P_p[0][1]-K[0][1]*P_p[1][1];
    kf->P[1][0]=P_p[1][0]-K[1][0]*P_p[0][0]-K[1][1]*P_p[1][0];
    kf->P[1][1]=P_p[1][1]-K[1][0]*P_p[0][1]-K[1][1]*P_p[1][1];

    return kf->x[0];
}

void FLIGHTCONTROLLER_Init_PID_Control(FLIGHTCONTROLLER_t* HandlePtr, FLIGHTCONTROLLER_PID_t* pid)
{
	pid->a[0] = 1 - pid->N * HandlePtr->config_ptr->period;
	pid->a[1] = pid->N * HandlePtr->config_ptr->period - 2;
	pid->b[0] = pid->P - pid->I * HandlePtr->config_ptr->period - pid->P * pid->N * HandlePtr->config_ptr->period + pid->N * pid->I * HandlePtr->config_ptr->period * HandlePtr->config_ptr->period + pid->D * pid->N;
	pid->b[1] = pid->I * HandlePtr->config_ptr->period - 2 * pid->P + pid->P * pid->N * HandlePtr->config_ptr->period - 2 * pid->D * pid->N;
	pid->b[2] = pid->P + pid->D * pid->N;

	pid->x[0] = pid->x[1] = 0;
}

void FLIGHTCONTROLLER_Init_P_Control(FLIGHTCONTROLLER_t* HandlePtr, FLIGHTCONTROLLER_PID_t* pid)
{
	pid->a[0] = 0;
	pid->a[1] = 0;
	pid->b[0] = 0;
	pid->b[1] = pid->P;
	pid->b[2] = 0;

	pid->x[0] = pid->x[1] = 0;
}

float FLIGHTCONTROLLER_PID_Control(FLIGHTCONTROLLER_PID_t* pid, float r, float y)
{
	//control error
	float e = (r-y)*DEG_TO_RAD;

	//calculate plant input
	float u = pid->x[pid->n-1]+pid->b[pid->n]*e;

	//calculate new coefficients
	for (int i=pid->n-1; i>0; i--)
		pid->x[i]=pid->b[i]*e-pid->a[i]*u+pid->x[i-1];

	pid->x[0]=pid->b[0]*e-pid->a[0]*u;

	u/=4.0;

	return u;
}

void FLIGHTCONTROLLER_CreateMotorSpeedsPercent(FLIGHTCONTROLLER_t* HandlePtr)
{
	if (HandlePtr->u[0] > HandlePtr->config_ptr->throttle_min)
	{
		HandlePtr->speed[0] = + HandlePtr->u[1] - HandlePtr->u[2] + HandlePtr->u[3] + HandlePtr->u[0];
		HandlePtr->speed[1] = - HandlePtr->u[1] - HandlePtr->u[2] - HandlePtr->u[3] + HandlePtr->u[0];
		HandlePtr->speed[2] = - HandlePtr->u[1] + HandlePtr->u[2] + HandlePtr->u[3] + HandlePtr->u[0];
		HandlePtr->speed[3] = + HandlePtr->u[1] + HandlePtr->u[2] - HandlePtr->u[3] + HandlePtr->u[0];
	}
	else
	{
		HandlePtr->speed[0]=HandlePtr->u[0];
		HandlePtr->speed[1]=HandlePtr->u[0];
		HandlePtr->speed[2]=HandlePtr->u[0];
		HandlePtr->speed[3]=HandlePtr->u[0];
	}

	if (HandlePtr->speed[0]>HandlePtr->config_ptr->speed_saturation_max)
		HandlePtr->speed[0]=HandlePtr->config_ptr->speed_saturation_max;

	if (HandlePtr->speed[0]<HandlePtr->config_ptr->speed_saturation_min)
		HandlePtr->speed[0]=HandlePtr->config_ptr->speed_saturation_min;

	if (HandlePtr->speed[1]>HandlePtr->config_ptr->speed_saturation_max)
		HandlePtr->speed[1]=HandlePtr->config_ptr->speed_saturation_max;

	if (HandlePtr->speed[1]<HandlePtr->config_ptr->speed_saturation_min)
		HandlePtr->speed[1]=HandlePtr->config_ptr->speed_saturation_min;

	if (HandlePtr->speed[2]>HandlePtr->config_ptr->speed_saturation_max)
		HandlePtr->speed[2]=HandlePtr->config_ptr->speed_saturation_max;

	if (HandlePtr->speed[2]<HandlePtr->config_ptr->speed_saturation_min)
		HandlePtr->speed[2]=HandlePtr->config_ptr->speed_saturation_min;

	if (HandlePtr->speed[3]>HandlePtr->config_ptr->speed_saturation_max)
		HandlePtr->speed[3]=HandlePtr->config_ptr->speed_saturation_max;

	if (HandlePtr->speed[3]<HandlePtr->config_ptr->speed_saturation_min)
		HandlePtr->speed[3]=HandlePtr->config_ptr->speed_saturation_min;
}

void FLIGHTCONTROLLER_lDCBusMeasurmentEventHandler(FLIGHTCONTROLLER_t* HandlePtr)
{
	uint16_t result = XMC_VADC_GROUP_GetResult(HandlePtr->channel_ptr->group_handle, HandlePtr->channel_ptr->ch_handle->result_reg_number);

	HandlePtr->motor_1_ccu8->zerocrossing_ptr->reference_voltage = result;
	HandlePtr->motor_2_ccu8->zerocrossing_ptr->reference_voltage = result;
	HandlePtr->motor_3_ccu4->zerocrossing_ptr->reference_voltage = result;
	HandlePtr->motor_4_ccu4->zerocrossing_ptr->reference_voltage = result;
}
